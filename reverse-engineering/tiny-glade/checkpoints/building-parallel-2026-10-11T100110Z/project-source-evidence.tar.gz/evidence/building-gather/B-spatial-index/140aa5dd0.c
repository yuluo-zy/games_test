
/* WARNING: Removing unreachable block (ram,0x000140aa61f3) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __cdecl
country_core::systems::wall::wall_state::wall_spatial_hash::WallSpatialHash::add_segment(void)

{
  char *pcVar1;
  longlong *plVar2;
  longlong *plVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  longlong lVar13;
  ulonglong extraout_RAX;
  longlong *extraout_RAX_00;
  longlong in_RCX;
  longlong lVar14;
  longlong lVar15;
  longlong lVar16;
  ulonglong uVar17;
  undefined8 *in_R9;
  longlong lVar18;
  uint uVar19;
  ushort uVar20;
  char cVar21;
  byte bVar22;
  char cVar24;
  char cVar25;
  char cVar26;
  undefined1 auVar23 [16];
  undefined4 in_XMM1_Da;
  undefined1 auVar27 [16];
  undefined4 in_XMM2_Da;
  undefined1 auVar28 [16];
  undefined1 unaff_XMM13_Ba;
  undefined1 unaff_XMM13_Bb;
  undefined1 unaff_XMM13_Bc;
  undefined1 unaff_XMM13_Bd;
  undefined1 unaff_XMM13_Be;
  undefined1 unaff_XMM13_Bf;
  undefined1 unaff_XMM13_Bg;
  undefined1 unaff_XMM13_Bh;
  undefined1 unaff_XMM13_Bi;
  undefined1 unaff_XMM13_Bj;
  undefined1 unaff_XMM13_Bk;
  undefined1 unaff_XMM13_Bl;
  undefined1 unaff_XMM13_Bm;
  undefined1 unaff_XMM13_Bn;
  undefined1 unaff_XMM13_Bo;
  undefined1 unaff_XMM13_Bp;
  undefined4 in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000038;
  undefined4 in_stack_00000040;
  longlong in_stack_00000048;
  longlong local_1e8;
  longlong local_1e0;
  ulonglong *local_f8;
  
  iVar4 = *(int *)(in_RCX + 0x58);
  uVar11 = *in_R9;
  uVar12 = in_R9[1];
  *(int *)(in_RCX + 0x58) = iVar4 + 1;
  local_f8 = (ulonglong *)&DAT_00000008;
  get_cells_from_segment<country_core::systems::wall::wall_state::wall_spatial_hash::impl_4::add_segment::closure_env_0>
            ();
  iVar7 = -(uint)(CONCAT13(unaff_XMM13_Bd,
                           CONCAT12(unaff_XMM13_Bc,CONCAT11(unaff_XMM13_Bb,unaff_XMM13_Ba))) ==
                 CONCAT13(unaff_XMM13_Bd,
                          CONCAT12(unaff_XMM13_Bc,CONCAT11(unaff_XMM13_Bb,unaff_XMM13_Ba))));
  iVar8 = -(uint)(CONCAT13(unaff_XMM13_Bh,
                           CONCAT12(unaff_XMM13_Bg,CONCAT11(unaff_XMM13_Bf,unaff_XMM13_Be))) ==
                 CONCAT13(unaff_XMM13_Bh,
                          CONCAT12(unaff_XMM13_Bg,CONCAT11(unaff_XMM13_Bf,unaff_XMM13_Be))));
  iVar9 = -(uint)(CONCAT13(unaff_XMM13_Bl,
                           CONCAT12(unaff_XMM13_Bk,CONCAT11(unaff_XMM13_Bj,unaff_XMM13_Bi))) ==
                 CONCAT13(unaff_XMM13_Bl,
                          CONCAT12(unaff_XMM13_Bk,CONCAT11(unaff_XMM13_Bj,unaff_XMM13_Bi))));
  iVar10 = -(uint)(CONCAT13(unaff_XMM13_Bp,
                            CONCAT12(unaff_XMM13_Bo,CONCAT11(unaff_XMM13_Bn,unaff_XMM13_Bm))) ==
                  CONCAT13(unaff_XMM13_Bp,
                           CONCAT12(unaff_XMM13_Bo,CONCAT11(unaff_XMM13_Bn,unaff_XMM13_Bm))));
LAB_140aa5fdf:
  do {
    if (local_f8 == (ulonglong *)&DAT_00000008) {
      return;
    }
    uVar17 = *local_f8;
    if (*(ulonglong *)(in_RCX + 0x10) <= uVar17) {
                    /* WARNING: Subroutine does not return */
      core::panicking::panic_bounds_check();
    }
    local_f8 = local_f8 + 1;
    lVar18 = *(longlong *)(in_RCX + 8);
    lVar15 = uVar17 * 0x30;
    plVar2 = (longlong *)(lVar18 + lVar15);
    lVar13 = *(longlong *)(lVar18 + 0x20 + lVar15);
    lVar14 = *(longlong *)(lVar18 + 0x28 + lVar15);
    lVar16 = 0;
    do {
      if (lVar14 * 8 - lVar16 == 0) {
        if (lVar14 == *(longlong *)(lVar18 + lVar15 + 0x18)) {
          alloc::raw_vec::RawVec::
          grow_one<bevy_ecs::event::base::EventInstance<tiny_glade::app_config::WriteSettingsFileCmd>,alloc::alloc::Global>
                    ();
          lVar13 = plVar2[4];
        }
        *(longlong *)(lVar13 + lVar14 * 8) = in_stack_00000048;
        plVar2[5] = lVar14 + 1;
        lVar18 = plVar2[2];
        if (lVar18 != *plVar2) goto LAB_140aa6089;
        goto LAB_140aa607a;
      }
      plVar3 = (longlong *)(lVar13 + lVar16);
      lVar16 = lVar16 + 8;
    } while (*plVar3 != in_stack_00000048);
    lVar18 = plVar2[2];
    if (lVar18 == *plVar2) {
LAB_140aa607a:
      alloc::raw_vec::RawVec::grow_one<enum2_<iced_core::event::Event>,alloc::alloc::Global>();
    }
LAB_140aa6089:
    lVar13 = plVar2[1];
    lVar14 = lVar18 * 0x38;
    *(undefined8 *)(lVar13 + lVar14) = uVar11;
    ((undefined8 *)(lVar13 + lVar14))[1] = uVar12;
    *(undefined4 *)(lVar13 + 0x10 + lVar14) = in_XMM1_Da;
    *(undefined4 *)(lVar13 + 0x14 + lVar14) = in_XMM2_Da;
    *(undefined4 *)(lVar13 + 0x18 + lVar14) = in_stack_00000028;
    *(undefined4 *)(lVar13 + 0x1c + lVar14) = in_stack_00000030;
    *(undefined4 *)(lVar13 + 0x20 + lVar14) = in_stack_00000038;
    *(undefined4 *)(lVar13 + 0x24 + lVar14) = in_stack_00000040;
    *(longlong *)(lVar13 + 0x28 + lVar14) = in_stack_00000048;
    *(int *)(lVar13 + 0x30 + lVar14) = iVar4;
    plVar2[2] = lVar18 + 1;
    if (*(longlong *)(in_RCX + 0x30) != 0) {
      core::hash::BuildHasher::
      hash_one<std::hash::random::RandomState,ref_<country_core::systems::ui::GlobalId>_>();
      bVar22 = (byte)(extraout_RAX >> 0x39);
      auVar23 = ZEXT216(CONCAT11(bVar22,bVar22));
      auVar23 = pshuflw(auVar23,auVar23,0);
      lVar18 = 0;
      uVar17 = extraout_RAX;
      while( true ) {
        uVar17 = *(ulonglong *)(in_RCX + 0x20) & uVar17;
        pcVar1 = (char *)(*(longlong *)(in_RCX + 0x18) + uVar17);
        cVar21 = auVar23[0];
        auVar28[0] = -(*pcVar1 == cVar21);
        cVar24 = auVar23[1];
        auVar28[1] = -(pcVar1[1] == cVar24);
        cVar25 = auVar23[2];
        auVar28[2] = -(pcVar1[2] == cVar25);
        cVar26 = auVar23[3];
        auVar28[3] = -(pcVar1[3] == cVar26);
        auVar28[4] = -(pcVar1[4] == cVar21);
        auVar28[5] = -(pcVar1[5] == cVar24);
        auVar28[6] = -(pcVar1[6] == cVar25);
        auVar28[7] = -(pcVar1[7] == cVar26);
        auVar28[8] = -(pcVar1[8] == cVar21);
        auVar28[9] = -(pcVar1[9] == cVar24);
        auVar28[10] = -(pcVar1[10] == cVar25);
        auVar28[0xb] = -(pcVar1[0xb] == cVar26);
        auVar28[0xc] = -(pcVar1[0xc] == cVar21);
        auVar28[0xd] = -(pcVar1[0xd] == cVar24);
        auVar28[0xe] = -(pcVar1[0xe] == cVar25);
        auVar28[0xf] = -(pcVar1[0xf] == cVar26);
        uVar20 = (ushort)(SUB161(auVar28 >> 7,0) & 1) | (ushort)(SUB161(auVar28 >> 0xf,0) & 1) << 1
                 | (ushort)(SUB161(auVar28 >> 0x17,0) & 1) << 2 |
                 (ushort)(SUB161(auVar28 >> 0x1f,0) & 1) << 3 |
                 (ushort)(SUB161(auVar28 >> 0x27,0) & 1) << 4 |
                 (ushort)(SUB161(auVar28 >> 0x2f,0) & 1) << 5 |
                 (ushort)(SUB161(auVar28 >> 0x37,0) & 1) << 6 |
                 (ushort)(SUB161(auVar28 >> 0x3f,0) & 1) << 7 |
                 (ushort)(SUB161(auVar28 >> 0x47,0) & 1) << 8 |
                 (ushort)(SUB161(auVar28 >> 0x4f,0) & 1) << 9 |
                 (ushort)(SUB161(auVar28 >> 0x57,0) & 1) << 10 |
                 (ushort)(SUB161(auVar28 >> 0x5f,0) & 1) << 0xb |
                 (ushort)(SUB161(auVar28 >> 0x67,0) & 1) << 0xc |
                 (ushort)(SUB161(auVar28 >> 0x6f,0) & 1) << 0xd |
                 (ushort)(SUB161(auVar28 >> 0x77,0) & 1) << 0xe | (ushort)(auVar28[0xf] >> 7) << 0xf
        ;
        uVar19 = (uint)uVar20;
        while (uVar20 != 0) {
          uVar5 = 0;
          for (uVar6 = uVar19; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
            uVar5 = uVar5 + 1;
          }
          if (*(longlong *)
               (*(longlong *)(in_RCX + 0x18) + -0x38 +
               (uVar5 + uVar17 & *(ulonglong *)(in_RCX + 0x20)) * -0x38) == in_stack_00000048) {
            hashbrown::map::HashMap::
            insert<usize,tuple_<>,std::hash::random::RandomState,alloc::alloc::Global>();
            goto LAB_140aa5fdf;
          }
          uVar20 = (ushort)(uVar19 - 1) & (ushort)uVar19;
          uVar19 = CONCAT22((short)(uVar19 - 1 >> 0x10),uVar20);
        }
        auVar27[0] = -(*pcVar1 == (char)iVar7);
        auVar27[1] = -(pcVar1[1] == (char)((uint)iVar7 >> 8));
        auVar27[2] = -(pcVar1[2] == (char)((uint)iVar7 >> 0x10));
        auVar27[3] = -(pcVar1[3] == (char)((uint)iVar7 >> 0x18));
        auVar27[4] = -(pcVar1[4] == (char)iVar8);
        auVar27[5] = -(pcVar1[5] == (char)((uint)iVar8 >> 8));
        auVar27[6] = -(pcVar1[6] == (char)((uint)iVar8 >> 0x10));
        auVar27[7] = -(pcVar1[7] == (char)((uint)iVar8 >> 0x18));
        auVar27[8] = -(pcVar1[8] == (char)iVar9);
        auVar27[9] = -(pcVar1[9] == (char)((uint)iVar9 >> 8));
        auVar27[10] = -(pcVar1[10] == (char)((uint)iVar9 >> 0x10));
        auVar27[0xb] = -(pcVar1[0xb] == (char)((uint)iVar9 >> 0x18));
        auVar27[0xc] = -(pcVar1[0xc] == (char)iVar10);
        auVar27[0xd] = -(pcVar1[0xd] == (char)((uint)iVar10 >> 8));
        auVar27[0xe] = -(pcVar1[0xe] == (char)((uint)iVar10 >> 0x10));
        auVar27[0xf] = -(pcVar1[0xf] == (char)((uint)iVar10 >> 0x18));
        if ((((((((((((((((SUB161(auVar27 >> 7,0) & 1) != 0 || (SUB161(auVar27 >> 0xf,0) & 1) != 0)
                        || (SUB161(auVar27 >> 0x17,0) & 1) != 0) ||
                       (SUB161(auVar27 >> 0x1f,0) & 1) != 0) || (SUB161(auVar27 >> 0x27,0) & 1) != 0
                      ) || (SUB161(auVar27 >> 0x2f,0) & 1) != 0) ||
                    (SUB161(auVar27 >> 0x37,0) & 1) != 0) || (SUB161(auVar27 >> 0x3f,0) & 1) != 0)
                  || (SUB161(auVar27 >> 0x47,0) & 1) != 0) || (SUB161(auVar27 >> 0x4f,0) & 1) != 0)
                || (SUB161(auVar27 >> 0x57,0) & 1) != 0) || (SUB161(auVar27 >> 0x5f,0) & 1) != 0) ||
              (SUB161(auVar27 >> 0x67,0) & 1) != 0) || (SUB161(auVar27 >> 0x6f,0) & 1) != 0) ||
            (SUB161(auVar27 >> 0x77,0) & 1) != 0) || auVar27[0xf] < '\0') break;
        uVar17 = uVar17 + lVar18 + 0x10;
        lVar18 = lVar18 + 0x10;
      }
    }
    core::ops::function::FnOnce::
    call_once<std::hash::random::impl_0::new::KEYS::constant_0::closure_env_1,tuple_<enum2_<core::option::Option<ref_mut_<enum2_<core::option::Option<core::cell::Cell<tuple_<u64,u64>_>_>_>_>_>_>_>_>
              ();
    if (extraout_RAX_00 == (longlong *)0x0) {
                    /* WARNING: Subroutine does not return */
      std::thread::local::panic_access_error();
    }
    *extraout_RAX_00 = *extraout_RAX_00 + 1;
    hashbrown::map::HashMap::
    insert<usize,tuple_<>,std::hash::random::RandomState,alloc::alloc::Global>();
    hashbrown::map::HashMap::
    insert<country_core::resources::walls::WallId,std::collections::hash::set::HashSet<usize,std::hash::random::RandomState>,std::hash::random::RandomState,alloc::alloc::Global>
              ();
    if (((local_1e8 != 0) && (local_1e0 != 0)) &&
       (local_1e0 + (local_1e0 * 8 + 0x17U & 0xfffffffffffffff0) != -0x11)) {
      std::alloc::__default_lib_allocator::__rust_dealloc();
    }
  } while( true );
}

