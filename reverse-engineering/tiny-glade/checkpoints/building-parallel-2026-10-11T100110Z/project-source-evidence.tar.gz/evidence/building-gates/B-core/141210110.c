
/* WARNING: Removing unreachable block (ram,0x00014121155a) */
/* WARNING: Removing unreachable block (ram,0x000141211560) */
/* WARNING: Removing unreachable block (ram,0x000141211773) */
/* WARNING: Removing unreachable block (ram,0x000141211789) */
/* WARNING: Removing unreachable block (ram,0x00014121179f) */
/* WARNING: Removing unreachable block (ram,0x0001412117c0) */
/* WARNING: Removing unreachable block (ram,0x0001412117d6) */
/* WARNING: Removing unreachable block (ram,0x0001412117e2) */
/* WARNING: Removing unreachable block (ram,0x0001412117f8) */
/* WARNING: Removing unreachable block (ram,0x000141211804) */
/* WARNING: Removing unreachable block (ram,0x000141211816) */
/* WARNING: Removing unreachable block (ram,0x000141211822) */
/* WARNING: Removing unreachable block (ram,0x000141211834) */
/* WARNING: Removing unreachable block (ram,0x000141211840) */
/* WARNING: Removing unreachable block (ram,0x00014121160f) */
/* WARNING: Removing unreachable block (ram,0x000141212894) */
/* WARNING: Removing unreachable block (ram,0x00014121184d) */
/* WARNING: Removing unreachable block (ram,0x00014121185e) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __cdecl system_wall_constructor::construct_gates::construct_wooden_gate_doors(void)

{
  float *pfVar1;
  float *pfVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  undefined4 uVar5;
  longlong lVar6;
  longlong lVar7;
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  int iVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined8 uVar14;
  void *_Src;
  bool bVar15;
  uint extraout_EAX;
  uint extraout_EAX_00;
  uint extraout_EAX_01;
  uint extraout_EAX_02;
  int extraout_EAX_03;
  uint extraout_EAX_04;
  uint extraout_EAX_05;
  uint extraout_EAX_06;
  uint extraout_EAX_07;
  float *extraout_RAX;
  float *extraout_RAX_00;
  void *extraout_RAX_01;
  ulonglong uVar16;
  undefined1 *extraout_RAX_02;
  longlong extraout_RAX_03;
  longlong lVar17;
  longlong lVar18;
  float *extraout_RAX_04;
  float *extraout_RAX_05;
  ulonglong uVar19;
  float *pfVar20;
  float *pfVar21;
  undefined8 extraout_RAX_06;
  ulonglong extraout_RAX_07;
  undefined8 extraout_RAX_08;
  float *extraout_RAX_09;
  float *extraout_RAX_10;
  float *extraout_RAX_11;
  longlong *in_RCX;
  float *pfVar22;
  undefined8 *puVar23;
  undefined4 *_Dst;
  float *pfVar24;
  float *pfVar25;
  float *pfVar26;
  uint uVar27;
  float *in_RDX;
  undefined1 *puVar28;
  char *pcVar29;
  undefined8 uVar30;
  longlong *plVar31;
  undefined1 auVar32 [8];
  longlong in_R8;
  ulonglong uVar33;
  undefined1 *puVar34;
  undefined1 *puVar35;
  undefined8 *puVar36;
  ulonglong uVar37;
  undefined1 *puVar38;
  float *pfVar39;
  float fVar40;
  float fVar41;
  float fVar42;
  float extraout_XMM0_Da;
  float extraout_XMM0_Da_00;
  float extraout_XMM0_Da_01;
  float extraout_XMM0_Da_02;
  float extraout_XMM0_Da_03;
  float extraout_XMM0_Da_04;
  float extraout_XMM0_Da_05;
  float extraout_XMM0_Da_06;
  float fVar43;
  float fVar44;
  float fVar45;
  float fVar46;
  float fVar47;
  float fVar48;
  float fVar49;
  float fVar50;
  float fVar51;
  float *in_stack_00000050;
  float in_stack_00000058;
  int in_stack_00000060;
  float local_454;
  float local_450;
  float local_44c;
  longlong local_430;
  float *local_348;
  float fStack_334;
  float *local_328;
  float *local_320;
  float *pfStack_318;
  longlong local_310;
  float *pfStack_308;
  undefined8 uStack_2f8;
  undefined8 local_2f0;
  undefined1 local_2e8 [8];
  float *local_2e0;
  undefined8 local_2d8;
  undefined8 uStack_2d0;
  undefined8 uStack_2c8;
  undefined8 uStack_2c0;
  undefined8 local_2b8;
  float fStack_2b0;
  float fStack_2ac;
  float *local_2a8;
  undefined8 uStack_2a0;
  undefined8 local_298;
  float fStack_290;
  undefined4 uStack_28c;
  undefined4 local_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_27c;
  float *local_278;
  undefined8 local_268;
  float *local_260;
  longlong local_258;
  float *local_250;
  longlong local_248;
  longlong lStack_240;
  longlong local_238;
  float *local_230;
  float *local_228;
  float local_220;
  float fStack_21c;
  float fStack_218;
  float fStack_214;
  float fStack_210;
  undefined4 uStack_20c;
  undefined8 local_208;
  undefined8 uStack_200;
  undefined8 uStack_1f8;
  undefined8 uStack_1f0;
  undefined8 uStack_1e8;
  float local_1e0;
  float fStack_1dc;
  undefined8 uStack_1d8;
  float local_1d0;
  float fStack_1cc;
  float fStack_1c8;
  float fStack_1c4;
  float fStack_1c0;
  undefined4 uStack_1bc;
  float *pfStack_1b8;
  void *pvStack_1b0;
  float *local_1a8;
  undefined8 local_198;
  undefined8 uStack_190;
  int local_188;
  undefined1 local_184;
  undefined8 local_178;
  undefined8 uStack_170;
  undefined8 local_168;
  undefined8 uStack_160;
  undefined8 uStack_158;
  undefined8 uStack_150;
  float local_13c;
  float *local_138;
  float fStack_130;
  float fStack_12c;
  float fStack_128;
  float fStack_124;
  float fStack_120;
  float local_11c;
  float *local_118;
  float *local_110;
  undefined8 local_108;
  float *local_100;
  undefined1 local_f7;
  undefined1 local_f6;
  undefined1 local_f5;
  undefined1 local_f4;
  undefined1 local_f3;
  undefined1 local_f2;
  undefined1 local_f1;
  undefined8 local_f0;
  
  local_f0 = 0xfffffffffffffffe;
  local_248 = 0;
  lStack_240 = 8;
  local_238 = 0;
  pfVar20 = *(float **)(in_R8 + 0x20);
  pfVar24 = *(float **)(in_R8 + 0x28);
  pfVar25 = pfVar20 + (longlong)pfVar24 * 3;
  uStack_1f8._0_4_ = 0.0;
  uStack_1f8._4_4_ = 0.0;
  pfVar21 = in_RDX;
  local_208 = (undefined **)pfVar20;
  uStack_200 = pfVar25;
  itertools::tuple_impl::impl$7::
  next<core::slice::iter::Iter<glam::f32::vec3::Vec3>,tuple_<ref_<glam::f32::vec3::Vec3>,ref_<glam::f32::vec3::Vec3>_>_>
            ();
  pfVar39 = extraout_RAX;
  fVar48 = __real_80000000;
  while (pfVar39 != (float *)0x0) {
    fVar43 = *pfVar39;
    fVar42 = pfVar39[1];
    fVar44 = pfVar39[2];
    fVar50 = *pfVar21;
    fVar45 = pfVar21[1];
    fVar47 = pfVar21[2];
    itertools::tuple_impl::impl$7::
    next<core::slice::iter::Iter<glam::f32::vec3::Vec3>,tuple_<ref_<glam::f32::vec3::Vec3>,ref_<glam::f32::vec3::Vec3>_>_>
              ();
    fVar48 = fVar48 + SQRT((fVar44 - fVar47) * (fVar44 - fVar47) +
                           (fVar42 - fVar45) * (fVar42 - fVar45) +
                           (fVar43 - fVar50) * (fVar43 - fVar50));
    pfVar39 = extraout_RAX_00;
  }
  if (pfVar24 == (float *)0x0) {
    local_178 = (float **)0x0;
    uStack_170 = (code *)0x4;
    local_168 = (float *)0x0;
                    /* WARNING: Subroutine does not return */
    core::panicking::panic_bounds_check();
  }
  std::alloc::__default_lib_allocator::__rust_alloc();
  if (extraout_RAX_01 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
    alloc::raw_vec::handle_error();
  }
  local_168 = (float *)0x0;
  local_178 = (float **)pfVar24;
  if (pfVar25 == (float *)&DAT_0000000c) {
                    /* WARNING: Subroutine does not return */
    core::option::unwrap_failed();
  }
  local_108 = CONCAT44(local_108._4_4_,in_stack_00000058 + __real_3f000000);
  fVar43 = *pfVar20;
  fVar42 = pfVar25[-3];
  lVar18 = *(longlong *)(in_R8 + 8);
  pfVar39 = *(float **)(in_R8 + 0x10);
  pfVar21 = pfVar24;
  if (pfVar39 < pfVar24) {
    pfVar21 = pfVar39;
  }
  fVar50 = 0.0;
  fVar44 = __real_7f7fffff;
  if (pfVar39 == (float *)0x0) {
    fVar45 = 0.0;
  }
  else {
    pfVar39 = pfVar20 + 1;
    fVar45 = 0.0;
    pfVar22 = (float *)0x0;
    do {
      fVar47 = *pfVar39;
      fVar46 = fVar44;
      if (fVar47 <= fVar44) {
        fVar46 = fVar47;
      }
      fVar44 = (float)(~-(uint)NAN(fVar47) & (uint)fVar46 | -(uint)NAN(fVar47) & (uint)fVar44);
      fVar47 = fVar47 + *(float *)(lVar18 + (longlong)pfVar22 * 4);
      pfVar22 = (float *)((longlong)pfVar22 + 1);
      fVar46 = fVar45;
      if (fVar45 <= fVar47) {
        fVar46 = fVar47;
      }
      fVar45 = (float)(-(uint)NAN(fVar47) & (uint)fVar45 | ~-(uint)NAN(fVar47) & (uint)fVar46);
      pfVar39 = pfVar39 + 3;
    } while (pfVar21 != pfVar22);
  }
  fVar47 = pfVar20[2];
  fVar46 = pfVar25[-1];
  fVar40 = fVar45 - (in_stack_00000058 + __real_3f000000);
  fVar49 = fVar44;
  if (fVar44 <= fVar40) {
    fVar49 = fVar40;
  }
  fVar49 = (float)(-(uint)NAN(fVar40) & (uint)fVar44 | ~-(uint)NAN(fVar40) & (uint)fVar49);
  pfVar39 = (float *)0x0;
  uStack_170 = extraout_RAX_01;
  local_118 = pfVar20;
  local_100 = pfVar25;
  do {
    fVar51 = fVar50 / fVar48;
    fVar41 = __real_3f800000 - fVar51;
    fVar40 = fVar51 * fVar42 + fVar41 * fVar43;
    do {
      pfVar22 = pfVar20;
      pfVar25 = local_168;
      _Src = uStack_170;
      if (pfVar22 == local_100) {
        auVar8._8_8_ = 0;
        auVar8._0_8_ = local_168;
        uVar16 = SUB168(auVar8 * ZEXT816(0xc),0);
        if ((SUB168(auVar8 * ZEXT816(0xc),8) != 0) || (0x7ffffffffffffffc < uVar16)) {
LAB_141213922:
                    /* WARNING: Subroutine does not return */
          alloc::raw_vec::handle_error();
        }
        if (uVar16 == 0) {
          puVar28 = &DAT_00000004;
        }
        else {
          std::alloc::__default_lib_allocator::__rust_alloc();
          puVar28 = extraout_RAX_02;
          if (extraout_RAX_02 == (undefined1 *)0x0) goto LAB_141213922;
        }
        memcpy(puVar28,_Src,uVar16);
        ::utils::curve::Curve::
        try_new_from_points<glam::f32::vec3::Vec3,utils::curve::CurveCoordSemantic3D>();
        pfVar20 = (float *)local_208;
        if (SBORROW8(0,(longlong)local_208)) {
          if (local_178 != (float **)0x0) {
            std::alloc::__default_lib_allocator::__rust_dealloc();
          }
          *in_RCX = 0;
          in_RCX[1] = 8;
          in_RCX[2] = 0;
          local_310 = local_248;
        }
        else {
          local_2d8 = (undefined **)uStack_200;
          uStack_2c0 = (float **)CONCAT44(uStack_1e8._4_4_,(float)uStack_1e8);
          local_2b8._0_4_ = local_1e0;
          local_2b8._4_4_ = fStack_1dc;
          fStack_2b0 = (float)uStack_1d8;
          fStack_2ac = uStack_1d8._4_4_;
          uStack_2c8._0_4_ = (float)uStack_1f0;
          uStack_2c8._4_4_ = uStack_1f0._4_4_;
          uStack_2d0._0_4_ = (float)uStack_1f8;
          uStack_2d0._4_4_ = uStack_1f8._4_4_;
          if (local_178 != (float **)0x0) {
            std::alloc::__default_lib_allocator::__rust_dealloc();
          }
          local_328 = pfVar20;
          pfVar20 = (float *)CONCAT44(uStack_2d0._4_4_,(float)uStack_2d0);
          local_310 = CONCAT44(uStack_2c8._4_4_,(float)uStack_2c8);
          uStack_2f8 = CONCAT44(fStack_2ac,fStack_2b0);
          local_320 = (float *)local_2d8;
          pfStack_308 = (float *)uStack_2c0;
          pfStack_318 = pfVar20;
          if (pfVar20 == (float *)0x0) {
            lVar17 = 4;
            pfVar25 = (float *)0x0;
          }
          else {
            std::alloc::__default_lib_allocator::__rust_alloc();
            lVar17 = extraout_RAX_03;
            pfVar25 = pfStack_318;
            if (extraout_RAX_03 == 0) {
                    /* WARNING: Subroutine does not return */
              alloc::raw_vec::handle_error();
            }
          }
          pfVar24 = local_320;
          uStack_200._0_4_ = (float)lVar17;
          uStack_200._4_4_ = (float)((ulonglong)lVar17 >> 0x20);
          local_430 = 0;
          local_110 = (float *)0x0;
          pfVar22 = (float *)0x0;
          local_208 = (undefined **)pfVar20;
          for (pfVar39 = (float *)0x0; pfVar20 = local_110, uStack_1f8 = local_110,
              pfVar39 < pfVar21; pfVar39 = (float *)((longlong)pfVar39 + 1)) {
            if (pfVar25 <= pfVar22) {
                    /* WARNING: Subroutine does not return */
              core::panicking::panic_bounds_check();
            }
            fVar48 = pfVar24[(longlong)pfVar22 * 3 + 1];
            fVar43 = local_118[(longlong)pfVar39 * 3 + 1];
            fVar42 = *(float *)(lVar18 + (longlong)pfVar39 * 4);
            if ((undefined **)local_110 == local_208) {
              alloc::raw_vec::RawVec::grow_one<f32,alloc::alloc::Global>();
            }
            pfVar22 = (float *)((longlong)pfVar22 + 1);
            *(float *)(CONCAT44(uStack_200._4_4_,(float)uStack_200) + (longlong)local_110 * 4) =
                 fVar42 - (fVar48 - fVar43);
            local_110 = (float *)((longlong)local_110 + 1);
            local_430 = local_430 + 4;
          }
          local_230 = (float *)CONCAT44(uStack_200._4_4_,(float)uStack_200);
          local_13c = (float)uStack_2f8;
          local_228 = (float *)local_208;
          pfVar25 = (float *)local_208;
          if ((float)local_108 < fVar45 - fVar44) {
            if (pfStack_318 == (float *)0x0) {
                    /* WARNING: Subroutine does not return */
              core::panicking::panic_bounds_check();
            }
            pfVar25 = local_320 + (longlong)pfStack_318 * 3;
            if (pfVar25 == (float *)&DAT_0000000c) {
                    /* WARNING: Subroutine does not return */
              core::option::unwrap_failed();
            }
            uVar30 = *(undefined8 *)local_320;
            fVar50 = (float)uVar30;
            fVar48 = local_320[2];
            uVar4 = *(undefined8 *)(pfVar25 + -3);
            fVar49 = (float)uVar4;
            fVar43 = pfVar25[-1];
            fVar42 = fVar49 - fVar50;
            fVar47 = fVar43 - fVar48;
            fVar46 = __real_3f800000 / SQRT(fVar47 * fVar47 + fVar42 * fVar42);
            local_208 = (undefined **)CONCAT44(fVar46 * fVar47,fVar42 * fVar46);
            ::utils::swizzlers::impl$0::x0y();
            fStack_334 = (float)((ulonglong)uVar30 >> 0x20);
            pfVar25 = local_228;
            fVar40 = local_44c;
            if (__real_40133333 <= (fVar45 - fVar44) - (float)local_108) {
joined_r0x0001412109f4:
              local_228 = pfVar25;
              if (fStack_334 <= 0.0) goto LAB_141211878;
              fVar45 = local_454 * ___xmm_00000000000000003f547ae23f547ae2;
              fVar47 = local_450 * _UNK_142c1be04;
              fVar42 = __real_3f547ae2 * local_44c;
              if (local_100[-2] < local_118[1] || local_100[-2] == local_118[1]) {
                ::utils::swizzlers::impl$0::x0y();
                fVar48 = fVar43 - fVar42;
                fVar45 = fVar49 - fVar45;
                fVar47 = (float)((ulonglong)uVar4 >> 0x20) - fVar47;
              }
              else {
                ::utils::swizzlers::impl$0::x0y();
                fVar48 = fVar48 + fVar42;
                fVar45 = fVar45 + fVar50;
                fVar47 = fVar47 + fStack_334;
              }
              fVar43 = (float)uStack_200;
              pfVar20 = (float *)local_208;
              local_1d0 = -9.014604e-06;
              fStack_1cc = 2.0947202e+27;
              uStack_1d8._0_4_ = 0.0;
              ::utils::xz_rotation_bad();
              bevy_app::plugin::Plugin::finish<country_core::systems::main_camera::MainCameraPlugin>
                        ();
              uStack_1f8._0_4_ =
                   SUB84(pfVar20,0) * ___xmm_00000000000000003f0f5c293f0f5c29 *
                   (float)__xmm_00000000000000003f0000003f000000 + fVar45;
              uStack_1f8._4_4_ =
                   (float)((ulonglong)pfVar20 >> 0x20) * _UNK_1429df1d4 *
                   __xmm_00000000000000003f0000003f000000._4_4_ + fVar47;
              uStack_1f0._0_4_ = fVar43 * __real_3f0f5c29 * __real_3f000000 + fVar48;
              fStack_1c8 = (float)CONCAT31(fStack_1c8._1_3_,3);
              uStack_1f0._4_4_ = 1.0;
              uStack_1e8._0_4_ = 1.0;
              uStack_1e8._4_4_ = 1.0;
              bevy_ecs::system::commands::Commands::spawn_empty();
              plVar31 = (longlong *)CONCAT44(uStack_2d0._4_4_,(float)uStack_2d0);
              if (plVar31 == (longlong *)0x0) {
                plVar31 = (longlong *)CONCAT44(uStack_2c8._4_4_,(float)uStack_2c8);
              }
              uVar30 = CONCAT44(local_2b8._4_4_,(float)local_2b8);
              lVar18 = plVar31[2];
              if ((ulonglong)(*plVar31 - lVar18) < 0x88) {
                alloc::raw_vec::impl$4::reserve::do_reserve_and_handle<alloc::alloc::Global>();
              }
              lVar6 = local_238;
              lVar17 = plVar31[1];
              *(code **)(lVar17 + lVar18) =
                   core::ops::function::FnOnce::
                   call_once<bevy_ecs::world::command_queue::impl_4::push::closure_env_0<bevy_ecs::error::command_handling::impl_0::handle_error_with::closure_env_0<bevy_ecs::error::command_handling::impl_3::with_entity::closure_env_0<bevy_ecs::system::commands::entity_command::insert::closure_env_0<country_core::components::drawable::NaniBundle<country_core::render::nani::instance_data::SolidVertexColorInstanceData>_>_>,tuple_<>,enum2_<bevy_ecs::world::error::EntityMutableFetchError>_>_>,tuple_<bevy_ptr::OwningPtr<bevy_ptr::Unaligned>,enum2_<core::option::Option<core::ptr::non_null::NonNull<bevy_ecs::world::World>_>_>,ref_mut_<usize>_>_>
              ;
              puVar36 = (undefined8 *)(lVar17 + 8 + lVar18);
              *puVar36 = local_208;
              puVar36[1] = CONCAT44(uStack_200._4_4_,(float)uStack_200);
              puVar36 = (undefined8 *)(lVar17 + 0x18 + lVar18);
              *puVar36 = CONCAT44(uStack_1f8._4_4_,(float)uStack_1f8);
              puVar36[1] = CONCAT44(uStack_1f0._4_4_,(float)uStack_1f0);
              puVar36 = (undefined8 *)(lVar17 + 0x28 + lVar18);
              *puVar36 = CONCAT44(uStack_1e8._4_4_,(float)uStack_1e8);
              puVar36[1] = CONCAT44(fStack_1dc,local_1e0);
              puVar36 = (undefined8 *)(lVar17 + 0x38 + lVar18);
              *puVar36 = CONCAT44(uStack_1d8._4_4_,(float)uStack_1d8);
              puVar36[1] = CONCAT44(fStack_1cc,local_1d0);
              puVar36 = (undefined8 *)(lVar17 + 0x48 + lVar18);
              *puVar36 = CONCAT44(fStack_1c4,fStack_1c8);
              puVar36[1] = CONCAT44(uStack_1bc,fStack_1c0);
              *(undefined1 *)(lVar17 + 0x58 + lVar18) = 0;
              *(undefined8 *)(lVar17 + 0x68 + lVar18) = uVar30;
              *(code **)(lVar17 + 0x78 + lVar18) = bevy_ecs::error::handler::panic;
              plVar31[2] = lVar18 + 0x88;
              if (local_238 == local_248) {
                alloc::raw_vec::RawVec::grow_one<usize,alloc::alloc::Global>();
              }
              *(undefined8 *)(lStack_240 + lVar6 * 8) = uVar30;
              local_238 = lVar6 + 1;
              uVar16 = 1;
            }
            else {
              fVar42 = (float)roundf();
              if (fVar42 <= __real_3f800000) {
                fVar42 = __real_3f800000;
              }
              uVar16 = 0;
              if (0.0 <= fVar42) {
                uVar16 = (longlong)(fVar42 - __real_5f000000) & (longlong)fVar42 >> 0x3f |
                         (longlong)fVar42;
              }
              uVar33 = 0xffffffffffffffff;
              if (fVar42 <= __real_5f7fffff) {
                uVar33 = uVar16;
              }
              uVar16 = 4;
              if (uVar33 < 4) {
                uVar16 = uVar33;
              }
              country_core::resources::terrain_height::TerrainHeightsData::
              sample_at_world_xz<country_core::resources::terrain_height::TerrainHeightSsbo>();
              country_core::resources::terrain_height::TerrainHeightsData::
              sample_at_world_xz<country_core::resources::terrain_height::TerrainHeightSsbo>();
              pfVar25 = local_228;
              if (__real_40133333 <=
                  (float)((uint)(extraout_XMM0_Da - extraout_XMM0_Da_00) &
                         ___xmm_7fffffff7fffffff7fffffff7fffffff) - (float)local_108)
              goto joined_r0x0001412109f4;
              if (fStack_334 <= 0.0) goto LAB_141211878;
            }
            fVar43 = __real_3e6b851f;
            fVar48 = __real_3dcccccd;
            local_118 = in_stack_00000050;
            local_348 = (float *)0x0;
            local_260 = (float *)0x0;
            local_258 = 4;
            local_250 = (float *)0x0;
            local_2f0 = 0;
            local_2e8 = (undefined1  [8])&DAT_00000004;
            local_2e0 = (float *)0x0;
            fVar44 = fVar44 + ___real_bf6b851f;
            local_220 = 0.0;
            fStack_21c = 0.0;
            fStack_218 = 5.60519e-45;
            fStack_214 = 0.0;
            fStack_210 = 0.0;
            uStack_20c = 0;
            fVar42 = local_44c * ___xmm_00000000000000003f0f5c293f0f5c29 *
                     (float)__xmm_00000000000000003f4ccccd3f4ccccd;
            fVar50 = local_454 * _UNK_1429df1d4 * __xmm_00000000000000003f4ccccd3f4ccccd._4_4_;
            auVar32 = (undefined1  [8])&DAT_00000004;
            local_100 = (float *)0x0;
            uVar33 = 0;
            fVar40 = fVar42;
            if (uVar16 != 0) {
              do {
                uVar19 = uVar33 + 1;
                fVar45 = (float)(longlong)uVar33;
                fVar47 = fVar45 * __real_beeb851f + fStack_334;
                if (fVar47 <= 0.0) {
                  if (uVar16 <= uVar19) break;
                  uVar37 = uVar33 + 2;
                  fVar45 = (float)(longlong)uVar19;
                  fVar47 = fVar45 * __real_beeb851f + fStack_334;
                  uVar19 = uVar37;
                  if (fVar47 <= 0.0) {
                    if (uVar16 <= uVar37) break;
                    uVar19 = uVar33 + 3;
                    fVar45 = (float)(longlong)uVar37;
                    fVar47 = fVar45 * __real_beeb851f + fStack_334;
                    if (fVar47 <= 0.0) {
                      if (uVar16 <= uVar19) break;
                      uVar37 = uVar33 + 4;
                      fVar45 = (float)(longlong)uVar19;
                      fVar47 = fVar45 * __real_beeb851f + fStack_334;
                      uVar19 = uVar37;
                      if (fVar47 <= 0.0) {
                        if (uVar16 <= uVar37) break;
                        fVar45 = (float)(longlong)uVar37;
                        fVar47 = fVar45 * __real_beeb851f + fStack_334;
                        uVar19 = uVar33 + 5;
                      }
                    }
                  }
                }
                local_108 = uVar19;
                fVar46 = fVar43 / (float)uStack_2f8;
                if (fVar48 <= fVar43 / (float)uStack_2f8) {
                  fVar46 = fVar48;
                }
                alloc::vec::spec_from_iter::impl$0::
                from_iter<glam::f32::vec2::Vec2,core::iter::adapters::map::Map<core::iter::adapters::copied::Copied<core::slice::iter::Iter<glam::f32::vec3::Vec3>_>,glam::f32::vec2::Vec2_(*)(glam::f32::vec3::Vec3)>_>
                          ();
                fVar49 = __real_3f800000;
                ::utils::curve::Curve::
                try_new_from_points<glam::f32::vec2::Vec2,utils::curve::CurveCoordSemantic2D>();
                if (SBORROW8(0,(longlong)local_208)) {
                  local_2d8 = (undefined **)CONCAT44(uStack_200._4_4_,(float)uStack_200);
                  uStack_2d0 = uStack_1f8;
                    /* WARNING: Subroutine does not return */
                  core::result::unwrap_failed();
                }
                local_2a8 = (float *)CONCAT44(uStack_1d8._4_4_,(float)uStack_1d8);
                uStack_2c0 = (float **)CONCAT44(uStack_1f0._4_4_,(float)uStack_1f0);
                local_2b8._0_4_ = (float)uStack_1e8;
                local_2b8._4_4_ = uStack_1e8._4_4_;
                fStack_2b0 = local_1e0;
                fStack_2ac = fStack_1dc;
                local_2d8 = local_208;
                uStack_2d0._0_4_ = (float)uStack_200;
                uStack_2d0._4_4_ = uStack_200._4_4_;
                local_138 = (float *)CONCAT44(local_138._4_4_,fVar46);
                uStack_2c8 = (float **)uStack_1f8;
                if (fVar46 < 0.0) {
                  local_178 = &local_138;
                  uStack_170 = core::fmt::float::impl$5::fmt;
                  local_208 = &anon_95101f4d2e0328d894274322bc39dc37_3_llvm_14090887955549727255;
                  uStack_200._0_4_ = 1.4013e-45;
                  uStack_200._4_4_ = 0.0;
                  uStack_1e8._0_4_ = 0.0;
                  uStack_1e8._4_4_ = 0.0;
                  uStack_1f0._0_4_ = 1.4013e-45;
                  uStack_1f0._4_4_ = 0.0;
                  puVar36 = &local_178;
                    /* WARNING: Subroutine does not return */
                  core::panicking::panic_fmt();
                  uStack_1f8 = (float *)puVar36;
                }
                fVar46 = fVar49 - fVar46;
                local_138 = (float *)CONCAT44(local_138._4_4_,fVar46);
                if ((fVar46 < 0.0) || (fVar49 < fVar46)) {
                  local_178 = &local_138;
                  uStack_170 = core::fmt::float::impl$5::fmt;
                  local_208 = &anon_95101f4d2e0328d894274322bc39dc37_3_llvm_14090887955549727255;
                  uStack_200._0_4_ = 1.4013e-45;
                  uStack_200._4_4_ = 0.0;
                  uStack_1e8._0_4_ = 0.0;
                  uStack_1e8._4_4_ = 0.0;
                  uStack_1f0._0_4_ = 1.4013e-45;
                  uStack_1f0._4_4_ = 0.0;
                  puVar36 = &local_178;
                    /* WARNING: Subroutine does not return */
                  core::panicking::panic_fmt();
                  uStack_1f8 = (float *)puVar36;
                }
                local_138 = (float *)0x0;
                fStack_130 = 5.60519e-45;
                fStack_12c = 0.0;
                fStack_128 = 0.0;
                fStack_124 = 0.0;
                local_f2 = 1;
                ::utils::curve::Curve::
                slice_into<glam::f32::vec2::Vec2,utils::curve::CurveCoordSemantic2D,alloc::vec::Vec<glam::f32::vec2::Vec2,alloc::alloc::Global>_>
                          ();
                local_168 = (float *)CONCAT44(fStack_124,fStack_128);
                uStack_170 = (code *)CONCAT44(fStack_12c,fStack_130);
                local_178 = (float **)local_138;
                local_f2 = 0;
                ::utils::curve::Curve::
                try_new_from_points<glam::f32::vec2::Vec2,utils::curve::CurveCoordSemantic2D>();
                pfVar24 = local_100;
                pfVar25 = uStack_1f8;
                pfVar20 = (float *)local_208;
                if (SBORROW8(0,(longlong)local_208)) {
                  local_178 = (float **)CONCAT44(uStack_200._4_4_,(float)uStack_200);
                  uStack_170 = (code *)uStack_1f8;
                  local_f2 = 0;
                    /* WARNING: Subroutine does not return */
                  core::result::unwrap_failed();
                }
                puVar36 = (undefined8 *)CONCAT44(uStack_200._4_4_,(float)uStack_200);
                lVar18 = CONCAT44(uStack_1f0._4_4_,(float)uStack_1f0);
                if (local_2d8 != (undefined **)0x0) {
                  std::alloc::__default_lib_allocator::__rust_dealloc();
                }
                if (uStack_2c0 != (float **)0x0) {
                  std::alloc::__default_lib_allocator::__rust_dealloc();
                }
                pfVar39 = pfVar25;
                if (pfVar25 == (float *)0x0) {
                  pfVar39 = (float *)0x0;
                }
                else {
                  fVar46 = fVar45 * fVar42;
                  fVar45 = fVar45 * fVar50;
                  uVar33 = (ulonglong)((longlong)pfVar25 + -1) & 0x1fffffffffffffff;
                  puVar23 = puVar36;
                  if (2 < uVar33) {
                    uVar33 = uVar33 + 1;
                    uVar19 = uVar33 & 0xfffffffffffffffc;
                    puVar23 = puVar36 + uVar19;
                    uVar37 = 0;
                    do {
                      pfVar21 = (float *)(puVar36 + uVar37);
                      fVar49 = pfVar21[1];
                      fVar40 = pfVar21[2];
                      fVar41 = pfVar21[3];
                      pfVar22 = (float *)(puVar36 + uVar37 + 2);
                      fVar51 = *pfVar22;
                      fVar11 = pfVar22[1];
                      fVar12 = pfVar22[2];
                      fVar13 = pfVar22[3];
                      pfVar22 = (float *)(puVar36 + uVar37);
                      *pfVar22 = *pfVar21 - fVar46;
                      pfVar22[1] = fVar49 + fVar45;
                      pfVar22[2] = fVar40 - fVar46;
                      pfVar22[3] = fVar41 + fVar45;
                      puVar3 = puVar36 + uVar37 + 2;
                      *puVar3 = CONCAT44(fVar11 + fVar45,fVar51 - fVar46);
                      *(float *)(puVar3 + 1) = fVar12 - fVar46;
                      *(float *)((longlong)puVar3 + 0xc) = fVar13 + fVar45;
                      uVar37 = uVar37 + 4;
                    } while (uVar19 != uVar37);
                    if (uVar33 == uVar19) goto LAB_141211123;
                  }
                  do {
                    *puVar23 = CONCAT44((float)((ulonglong)*puVar23 >> 0x20) + fVar45,
                                        (float)*puVar23 - fVar46);
                    puVar23 = puVar23 + 1;
                  } while (puVar23 != puVar36 + (longlong)pfVar25);
                }
LAB_141211123:
                if (pfVar39 <= pfVar24) {
                  pfVar24 = pfVar39;
                }
                if (pfVar24 != (float *)0x0) {
                  uVar33 = (ulonglong)((longlong)pfVar24 + -1) & 0x3fffffffffffffff;
                  pfVar21 = (float *)auVar32;
                  if (6 < uVar33) {
                    uVar33 = uVar33 + 1;
                    uVar19 = uVar33 & 0xfffffffffffffff8;
                    pfVar21 = (float *)((longlong)auVar32 + uVar19 * 4);
                    uVar37 = 0;
                    do {
                      pfVar39 = (float *)((longlong)auVar32 + uVar37 * 4);
                      *pfVar39 = fVar47;
                      pfVar39[1] = fVar47;
                      pfVar39[2] = fVar47;
                      pfVar39[3] = fVar47;
                      pfVar39 = (float *)((longlong)auVar32 + (uVar37 + 4) * 4);
                      *pfVar39 = fVar47;
                      pfVar39[1] = fVar47;
                      pfVar39[2] = fVar47;
                      pfVar39[3] = fVar47;
                      uVar37 = uVar37 + 8;
                    } while (uVar19 != uVar37);
                    pfVar39 = pfVar25;
                    if (uVar33 == uVar19) goto LAB_1412111a5;
                  }
                  do {
                    *pfVar21 = fVar47;
                    pfVar21 = pfVar21 + 1;
                    pfVar39 = pfVar25;
                  } while (pfVar21 != (float *)((longlong)auVar32 + pfVar24 * 4));
                }
LAB_1412111a5:
                uVar33 = (longlong)pfVar39 - (longlong)pfVar24;
                pfVar21 = pfVar39;
                if (pfVar24 <= pfVar39 && uVar33 != 0) {
                  local_2e0 = pfVar24;
                  if ((ulonglong)(local_2f0 - (longlong)pfVar24) < uVar33) {
                    alloc::raw_vec::impl$4::reserve::do_reserve_and_handle<alloc::alloc::Global>();
                    pfVar21 = (float *)((longlong)local_2e8 + local_2e0 * 4);
                  }
                  else {
                    pfVar21 = (float *)((longlong)local_2e8 + pfVar24 * 4);
                  }
                  if (1 < uVar33) {
                    puVar34 = (undefined1 *)(~(ulonglong)pfVar24 + (longlong)pfVar39);
                    puVar28 = (undefined1 *)0x1;
                    if (puVar34 < (undefined1 *)0x8) {
LAB_141211229:
                      puVar28 = (undefined1 *)
                                ((longlong)pfVar24 + ((longlong)puVar28 - (longlong)pfVar39));
                      do {
                        *pfVar21 = fVar47;
                        pfVar21 = pfVar21 + 1;
                        puVar28 = puVar28 + 1;
                      } while (puVar28 != (undefined1 *)0x0);
                    }
                    else {
                      puVar35 = (undefined1 *)((ulonglong)puVar34 & 0xfffffffffffffff8);
                      pfVar21 = pfVar21 + (longlong)puVar35;
                      puVar28 = puVar35 + 1;
                      puVar38 = (undefined1 *)0x0;
                      do {
                        pfVar22 = (float *)((longlong)local_2e8 +
                                           (undefined1 *)((longlong)local_2e0 + (longlong)puVar38) *
                                           4);
                        *pfVar22 = fVar47;
                        pfVar22[1] = fVar47;
                        pfVar22[2] = fVar47;
                        pfVar22[3] = fVar47;
                        pfVar22 = (float *)((longlong)local_2e8 +
                                           (undefined1 *)
                                           ((longlong)local_2e0 + (longlong)(puVar38 + 4)) * 4);
                        *pfVar22 = fVar47;
                        pfVar22[1] = fVar47;
                        pfVar22[2] = fVar47;
                        pfVar22[3] = fVar47;
                        puVar38 = puVar38 + 8;
                      } while (puVar35 != puVar38);
                      if (puVar34 != puVar35) goto LAB_141211229;
                    }
                    local_2e0 = (float *)((longlong)local_2e0 + (uVar33 - 1));
                  }
                  *pfVar21 = fVar47;
                  pfVar39 = (float *)((longlong)local_2e0 + 1);
                  pfVar21 = pfVar25;
                }
                uVar33 = (longlong)pfVar21 - (longlong)local_348;
                local_2e0 = pfVar39;
                pfVar24 = local_250;
                local_100 = pfVar39;
                if (local_348 <= pfVar21 && uVar33 != 0) {
                  if ((ulonglong)-(longlong)local_348 < uVar33) {
                    alloc::raw_vec::impl$4::reserve::do_reserve_and_handle<alloc::alloc::Global>();
                  }
                  _Dst = (undefined4 *)((longlong)local_348 * 4 + 4);
                  if (1 < uVar33) {
                    memset(_Dst,0,(longlong)(~(ulonglong)local_348 + (longlong)pfVar21) * 4);
                    _Dst = (undefined4 *)((longlong)pfVar21 * 4);
                    local_348 = (float *)((longlong)local_348 + (uVar33 - 1));
                  }
                  pfVar39 = local_250;
                  *_Dst = 0;
                  local_348 = (float *)((longlong)local_348 + 1);
                  uVar33 = (longlong)pfVar25 - (longlong)local_250;
                  pfVar24 = pfVar25;
                  if (local_250 <= pfVar25 && uVar33 != 0) {
                    if ((ulonglong)((longlong)local_260 - (longlong)local_250) < uVar33) {
                      alloc::raw_vec::impl$4::reserve::do_reserve_and_handle<alloc::alloc::Global>()
                      ;
                      pfVar24 = (float *)(local_258 + (longlong)local_250 * 4);
                    }
                    else {
                      pfVar24 = (float *)(local_258 + (longlong)local_250 * 4);
                    }
                    if (1 < uVar33) {
                      puVar34 = (undefined1 *)(~(ulonglong)pfVar39 + (longlong)pfVar25);
                      puVar28 = (undefined1 *)0x1;
                      if (puVar34 < (undefined1 *)0x8) {
LAB_141211369:
                        puVar28 = (undefined1 *)
                                  ((longlong)pfVar39 + ((longlong)puVar28 - (longlong)pfVar25));
                        do {
                          *pfVar24 = fVar44;
                          pfVar24 = pfVar24 + 1;
                          puVar28 = puVar28 + 1;
                        } while (puVar28 != (undefined1 *)0x0);
                      }
                      else {
                        puVar35 = (undefined1 *)((ulonglong)puVar34 & 0xfffffffffffffff8);
                        pfVar24 = pfVar24 + (longlong)puVar35;
                        puVar28 = puVar35 + 1;
                        lVar17 = local_258 + (longlong)local_250 * 4;
                        puVar38 = (undefined1 *)0x0;
                        do {
                          pfVar21 = (float *)(lVar17 + (longlong)puVar38 * 4);
                          *pfVar21 = fVar44;
                          pfVar21[1] = fVar44;
                          pfVar21[2] = fVar44;
                          pfVar21[3] = fVar44;
                          pfVar21 = (float *)(lVar17 + 0x10 + (longlong)puVar38 * 4);
                          *pfVar21 = fVar44;
                          pfVar21[1] = fVar44;
                          pfVar21[2] = fVar44;
                          pfVar21[3] = fVar44;
                          puVar38 = puVar38 + 8;
                        } while (puVar35 != puVar38);
                        if (puVar34 != puVar35) goto LAB_141211369;
                      }
                      local_250 = (float *)((longlong)local_250 + (uVar33 - 1));
                    }
                    *pfVar24 = fVar44;
                    pfVar24 = (float *)((longlong)local_250 + 1);
                  }
                }
                local_250 = pfVar24;
                country_core::geometry::instanced_wall::impl$1::from();
                auVar32 = local_2e8;
                if (local_250 < pfVar25) {
                    /* WARNING: Subroutine does not return */
                  core::slice::index::slice_end_index_len_fail();
                }
                if (local_348 < pfVar25) {
                    /* WARNING: Subroutine does not return */
                  core::slice::index::slice_end_index_len_fail();
                }
                local_208 = (undefined **)0x0;
                uStack_200._0_4_ = 5.60519e-45;
                uStack_200._4_4_ = 0.0;
                uStack_1f8._0_4_ = 0.0;
                uStack_1f8._4_4_ = 0.0;
                uStack_1f0._0_4_ = 0.0;
                uStack_1f0._4_4_ = (float)((uint)uStack_1f0._4_4_ & 0xffffff00);
                uStack_1e8._0_4_ = 0.0;
                uStack_1e8._4_4_ = 0.0;
                fStack_1c0 = 0.0;
                uStack_1bc = 0;
                pfStack_1b8 = (float *)0x0;
                local_1d0 = 0.0;
                fStack_1cc = 0.0;
                fStack_1c8 = 0.0;
                fStack_1c4 = 0.0;
                local_1e0 = 5.60519e-45;
                fStack_1dc = 0.0;
                uStack_1d8._0_4_ = 0.0;
                uStack_1d8._4_4_ = 0.0;
                uStack_2c8._4_4_ = (float)CONCAT31(uStack_2c8._5_3_,2);
                wall_constructor::WallConstructor::from_curve();
                if (local_208 != (undefined **)0x0) {
                  std::alloc::__default_lib_allocator::__rust_dealloc();
                }
                if (CONCAT44(uStack_1e8._4_4_,(float)uStack_1e8) != 0) {
                  std::alloc::__default_lib_allocator::__rust_dealloc();
                }
                if (pfVar20 != (float *)0x0) {
                  std::alloc::__default_lib_allocator::__rust_dealloc();
                }
                if (lVar18 != 0) {
                  std::alloc::__default_lib_allocator::__rust_dealloc();
                }
                uVar33 = local_108;
                fVar40 = fVar43;
              } while (local_108 < uVar16);
            }
            if (CONCAT44(fStack_21c,local_220) != 0) {
              std::alloc::__default_lib_allocator::__rust_dealloc();
            }
            pfVar20 = local_110;
            pfVar25 = local_228;
            if (local_2f0 != 0) {
              std::alloc::__default_lib_allocator::__rust_dealloc();
            }
            if (local_260 != (float *)0x0) {
              std::alloc::__default_lib_allocator::__rust_dealloc();
            }
          }
LAB_141211878:
          pfVar39 = pfStack_318;
          pfVar24 = local_320;
          if (pfStack_318 == (float *)0x0) {
                    /* WARNING: Subroutine does not return */
            core::panicking::panic_bounds_check();
          }
          pfVar21 = local_320 + (longlong)pfStack_318 * 3;
          if (pfVar21 == (float *)&DAT_0000000c) {
                    /* WARNING: Subroutine does not return */
            core::option::unwrap_failed();
          }
          fVar48 = pfVar21[-1] - local_320[2];
          fVar43 = pfVar21[-3] - *local_320;
          fVar42 = __real_3f800000 / SQRT(fVar43 * fVar43 + fVar48 * fVar48);
          if ((int)fVar42 - 1U < 0x7fffff ||
              (int)ABS(fVar42) - 0x800000U < 0x7f000000 && -1 < (int)fVar42) {
            local_2d8 = (undefined **)
                        CONCAT44(fVar43 * fVar42,
                                 fVar48 * (float)(___xmm_80000000800000008000000080000000 ^
                                                 (uint)fVar42));
            ::utils::swizzlers::impl$0::x0y();
            pfVar25 = pfStack_318;
            if ((longlong)pfVar39 * 0xc != 0) {
              fVar48 = SUB84(local_208,0) * ___xmm_00000000000000003e2c08323e2c0832;
              fVar43 = (float)((ulonglong)local_208 >> 0x20) * _UNK_142c1be24;
              fVar42 = (float)uStack_200 * ___real_3e2c0832;
              uVar16 = (longlong)pfVar39 * 0xc - 0xc;
              auVar9._8_8_ = 0;
              auVar9._0_8_ = uVar16;
              uVar27 = (SUB164(auVar9 * ZEXT816(0xaaaaaaaaaaaaaaab),8) >> 3) + 1 & 3;
              if (uVar27 != 0) {
                lVar18 = (ulonglong)(uVar27 << 2) * 3;
                do {
                  *(ulonglong *)pfVar24 =
                       CONCAT44((float)((ulonglong)*(undefined8 *)pfVar24 >> 0x20) + fVar43,
                                (float)*(undefined8 *)pfVar24 + fVar48);
                  pfVar24[2] = pfVar24[2] + fVar42;
                  pfVar24 = pfVar24 + 3;
                  lVar18 = lVar18 + -0xc;
                } while (lVar18 != 0);
              }
              if (0x23 < uVar16) {
                do {
                  *(ulonglong *)pfVar24 =
                       CONCAT44((float)((ulonglong)*(undefined8 *)pfVar24 >> 0x20) + fVar43,
                                (float)*(undefined8 *)pfVar24 + fVar48);
                  pfVar24[2] = pfVar24[2] + fVar42;
                  *(ulonglong *)(pfVar24 + 3) =
                       CONCAT44((float)((ulonglong)*(undefined8 *)(pfVar24 + 3) >> 0x20) + fVar43,
                                (float)*(undefined8 *)(pfVar24 + 3) + fVar48);
                  pfVar24[5] = pfVar24[5] + fVar42;
                  *(ulonglong *)(pfVar24 + 6) =
                       CONCAT44((float)((ulonglong)*(undefined8 *)(pfVar24 + 6) >> 0x20) + fVar43,
                                (float)*(undefined8 *)(pfVar24 + 6) + fVar48);
                  pfVar24[8] = pfVar24[8] + fVar42;
                  *(ulonglong *)(pfVar24 + 9) =
                       CONCAT44((float)((ulonglong)*(undefined8 *)(pfVar24 + 9) >> 0x20) + fVar43,
                                (float)*(undefined8 *)(pfVar24 + 9) + fVar48);
                  pfVar24[0xb] = pfVar24[0xb] + fVar42;
                  pfVar24 = pfVar24 + 0xc;
                } while (pfVar24 != pfVar21);
              }
            }
            if (local_13c <= __real_402ccccd) {
              std::alloc::__default_lib_allocator::__rust_alloc();
              if (extraout_RAX_05 == (float *)0x0) {
                    /* WARNING: Subroutine does not return */
                alloc::alloc::handle_alloc_error();
              }
              *(undefined8 *)extraout_RAX_05 = __xmm_00000000000000003f80000000000000;
              *(float **)(extraout_RAX_05 + 2) = pfStack_318;
              *(undefined1 *)(extraout_RAX_05 + 4) = 0;
              lVar18 = 1;
              pfVar25 = extraout_RAX_05;
            }
            else {
              std::alloc::__default_lib_allocator::__rust_alloc();
              if (extraout_RAX_04 == (float *)0x0) {
                    /* WARNING: Subroutine does not return */
                alloc::alloc::handle_alloc_error();
              }
              fVar48 = __real_3d4ccccd / local_13c;
              if (__real_3dcccccd <= __real_3d4ccccd / local_13c) {
                fVar48 = __real_3dcccccd;
              }
              uVar16 = (ulonglong)pfVar25 >> 1;
              lVar18 = 2;
              if (uVar16 < 3) {
                uVar16 = 2;
              }
              fVar43 = __real_3f000000 - fVar48;
              fVar48 = fVar48 + __real_3f000000;
              *extraout_RAX_04 = 0.0;
              extraout_RAX_04[1] = fVar43;
              *(ulonglong *)(extraout_RAX_04 + 2) = uVar16;
              *(undefined1 *)(extraout_RAX_04 + 4) = 1;
              extraout_RAX_04[6] = fVar48;
              extraout_RAX_04[7] = 1.0;
              *(ulonglong *)(extraout_RAX_04 + 8) = uVar16;
              *(undefined1 *)(extraout_RAX_04 + 10) = 1;
              pfVar25 = extraout_RAX_04;
            }
            lVar17 = *(longlong *)(in_R8 + 0x38);
            lVar6 = *(longlong *)(in_R8 + 0x40);
            pfVar24 = local_230 + (longlong)pfVar20;
            local_108 = 0;
            pfVar39 = pfVar25;
            while (pfVar22 = pfStack_318, pfVar21 = local_320, pfVar39 != pfVar25 + lVar18 * 6) {
              if (pfStack_318 == (float *)0x0) {
                local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                core::panicking::panic_bounds_check();
              }
              pfVar20 = local_320 + (longlong)pfStack_318 * 3;
              if (pfVar20 == (float *)&DAT_0000000c) {
                local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                core::option::unwrap_failed();
              }
              fVar43 = (float)uStack_2f8;
              fVar48 = pfVar20[-1] - local_320[2];
              fVar42 = pfVar20[-3] - *local_320;
              fVar44 = __real_3f800000 / SQRT(fVar42 * fVar42 + fVar48 * fVar48);
              local_208 = (undefined **)
                          CONCAT44(fVar44 * fVar42,
                                   (float)((uint)fVar44 ^ ___xmm_80000000800000008000000080000000) *
                                   fVar48);
              local_f1 = 1;
              ::utils::swizzlers::impl$0::x0y();
              uVar19 = local_108 + 1;
              uVar16 = *(ulonglong *)(pfVar39 + 2);
              local_100 = (float *)CONCAT71(local_100._1_7_,*(undefined1 *)(pfVar39 + 4));
              fVar48 = *pfVar39;
              local_118 = (float *)CONCAT44(local_118._4_4_,pfVar39[1]);
              uVar33 = 0;
              bVar15 = false;
              if (uVar16 != 0) {
                do {
                  if ((longlong)uVar33 < 0) {
                    fVar42 = (float)uVar33;
                    uVar37 = *(ulonglong *)(pfVar39 + 2);
                    if (-1 < (longlong)uVar37) goto LAB_141211d84;
LAB_141211d46:
                    fVar44 = (float)uVar37;
                  }
                  else {
                    fVar42 = (float)(longlong)uVar33;
                    uVar37 = *(ulonglong *)(pfVar39 + 2);
                    if ((longlong)uVar37 < 0) goto LAB_141211d46;
LAB_141211d84:
                    fVar44 = (float)(longlong)uVar37;
                  }
                  uVar37 = uVar33 + 1;
                  fVar42 = fVar42 / (fVar44 + __real_bf800000);
                  fVar50 = fVar42 * pfVar39[1] + (__real_3f800000 - fVar42) * *pfVar39;
                  fVar42 = fVar40;
                  if (!bVar15) {
                    if (uVar16 <= uVar37) break;
                    fVar44 = (float)uVar37 / (fVar44 + __real_bf800000);
                    fVar42 = fVar50;
                    uVar37 = uVar33 + 2;
                    fVar50 = pfVar39[1] * fVar44 + *pfVar39 * (__real_3f800000 - fVar44);
                  }
                  fVar40 = fVar50;
                  uVar33 = uVar37;
                  local_138._0_4_ = fVar42;
                  if ((fVar42 < 0.0) || (__real_3f800000 < fVar42)) {
                    local_178 = &local_138;
                    uStack_170 = core::fmt::float::impl$5::fmt;
                    local_208 = &anon_95101f4d2e0328d894274322bc39dc37_3_llvm_14090887955549727255;
                    uStack_200._0_4_ = 1.4013e-45;
                    uStack_200._4_4_ = 0.0;
                    uStack_1e8._0_4_ = 0.0;
                    uStack_1e8._4_4_ = 0.0;
                    uStack_1f8 = (float *)&local_178;
                    uStack_1f0._0_4_ = 1.4013e-45;
                    uStack_1f0._4_4_ = 0.0;
                    local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                    core::panicking::panic_fmt();
                  }
                  if (NAN(fVar42)) {
                    local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                    core::panicking::panic();
                  }
                  local_f1 = 1;
                  ::utils::curve::Curve::
                  get_coord_at_u<glam::f32::vec3::Vec3,utils::curve::CurveCoordSemantic3D,utils::curve::curve_u::CurveU<utils::curve::CurveCoordSemantic3D>_>
                            ();
                  local_138 = (float *)CONCAT44(local_138._4_4_,fVar40);
                  if ((fVar40 < 0.0) || (__real_3f800000 < fVar40)) {
                    local_178 = &local_138;
                    uStack_170 = core::fmt::float::impl$5::fmt;
                    local_208 = &anon_95101f4d2e0328d894274322bc39dc37_3_llvm_14090887955549727255;
                    uStack_200._0_4_ = 1.4013e-45;
                    uStack_200._4_4_ = 0.0;
                    uStack_1e8._0_4_ = 0.0;
                    uStack_1e8._4_4_ = 0.0;
                    uStack_1f8 = (float *)&local_178;
                    uStack_1f0._0_4_ = 1.4013e-45;
                    uStack_1f0._4_4_ = 0.0;
                    local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                    core::panicking::panic_fmt();
                  }
                  if (NAN(fVar40)) {
                    local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                    core::panicking::panic();
                  }
                  local_f1 = 1;
                  ::utils::curve::Curve::
                  get_coord_at_u<glam::f32::vec3::Vec3,utils::curve::CurveCoordSemantic3D,utils::curve::curve_u::CurveU<utils::curve::CurveCoordSemantic3D>_>
                            ();
                  pfVar20 = (float *)(ulonglong)extraout_EAX;
                  if (local_110 <= pfVar20) {
                    local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                    core::panicking::panic_bounds_check();
                  }
                  pfVar1 = (float *)((longlong)pfVar20 + 1);
                  if (local_110 <= pfVar1) {
                    local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                    core::panicking::panic_bounds_check();
                  }
                  pfVar26 = (float *)(ulonglong)extraout_EAX_00;
                  if (local_110 <= pfVar26) {
                    local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                    core::panicking::panic_bounds_check();
                  }
                  pfVar2 = (float *)((longlong)pfVar26 + 1);
                  if (local_110 <= pfVar2) {
                    local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                    core::panicking::panic_bounds_check();
                  }
                  if (pfVar22 <= pfVar20) {
                    local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                    core::panicking::panic_bounds_check();
                  }
                  if (pfVar22 <= pfVar1) {
                    local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                    core::panicking::panic_bounds_check();
                  }
                  if (pfVar22 <= pfVar26) {
                    local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                    core::panicking::panic_bounds_check();
                  }
                  if (pfVar22 <= pfVar2) {
                    local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                    core::panicking::panic_bounds_check();
                  }
                  fVar50 = (local_230[(longlong)((longlong)pfVar20 + 1)] -
                           local_230[(longlong)pfVar20]) * extraout_XMM0_Da_01 +
                           local_230[(longlong)pfVar20];
                  fVar45 = (local_230[(longlong)((longlong)pfVar26 + 1)] -
                           local_230[(longlong)pfVar26]) * extraout_XMM0_Da_02 +
                           local_230[(longlong)pfVar26];
                  local_2b8._4_4_ = (float)*(undefined8 *)(pfVar21 + (longlong)pfVar20 * 3);
                  fStack_2b0 = (float)((ulonglong)*(undefined8 *)(pfVar21 + (longlong)pfVar20 * 3)
                                      >> 0x20);
                  local_2b8._4_4_ =
                       extraout_XMM0_Da_01 *
                       ((float)*(undefined8 *)(pfVar21 + (longlong)pfVar1 * 3) - local_2b8._4_4_) +
                       local_2b8._4_4_;
                  fStack_2b0 = extraout_XMM0_Da_01 *
                               ((float)((ulonglong)*(undefined8 *)(pfVar21 + (longlong)pfVar1 * 3)
                                       >> 0x20) - fStack_2b0) + fStack_2b0;
                  uStack_2d0._0_4_ =
                       (pfVar21[(longlong)pfVar1 * 3 + 2] - pfVar21[(longlong)pfVar20 * 3 + 2]) *
                       extraout_XMM0_Da_01 + pfVar21[(longlong)pfVar20 * 3 + 2];
                  local_2d8 = (undefined **)CONCAT44(fStack_2b0,local_2b8._4_4_);
                  uStack_2d0._4_4_ = (float)*(undefined8 *)(pfVar21 + (longlong)pfVar26 * 3);
                  uStack_2c8._0_4_ =
                       (float)((ulonglong)*(undefined8 *)(pfVar21 + (longlong)pfVar26 * 3) >> 0x20);
                  uStack_2d0._4_4_ =
                       extraout_XMM0_Da_02 *
                       ((float)*(undefined8 *)(pfVar21 + (longlong)pfVar2 * 3) - uStack_2d0._4_4_) +
                       uStack_2d0._4_4_;
                  uStack_2c8._0_4_ =
                       extraout_XMM0_Da_02 *
                       ((float)((ulonglong)*(undefined8 *)(pfVar21 + (longlong)pfVar2 * 3) >> 0x20)
                       - (float)uStack_2c8) + (float)uStack_2c8;
                  uStack_2c8._4_4_ =
                       pfVar21[(longlong)pfVar26 * 3 + 2] +
                       (pfVar21[(longlong)pfVar2 * 3 + 2] - pfVar21[(longlong)pfVar26 * 3 + 2]) *
                       extraout_XMM0_Da_02;
                  uStack_2c0 = (float **)
                               CONCAT44((float)uStack_2c8 + fVar45,uStack_2d0._4_4_ + fVar45 * 0.0);
                  local_2b8._0_4_ = uStack_2c8._4_4_ + fVar45 * 0.0;
                  local_2b8._4_4_ = local_2b8._4_4_ + fVar50 * 0.0;
                  fStack_2b0 = fStack_2b0 + fVar50;
                  fStack_2ac = (float)uStack_2d0 + fVar50 * 0.0;
                  fVar44 = fVar40;
                  if (((ulonglong)local_100 & 1) != 0) {
                    if ((fVar48 != 0.0) || (NAN(fVar48))) {
                      fVar42 = fVar42 - fVar48;
                      fVar44 = fVar40 - fVar48;
                    }
                    else {
                      fVar42 = local_118._0_4_ - fVar42;
                      fVar44 = local_118._0_4_ - fVar40;
                    }
                  }
                  uStack_200._0_4_ = fStack_218;
                  local_208 = (undefined **)CONCAT44(fStack_21c,local_220);
                  uStack_1f8._4_4_ = fStack_218;
                  uStack_200._4_4_ = local_220;
                  uStack_1f8._0_4_ = fStack_21c;
                  uStack_1e8._0_4_ = fStack_218;
                  uStack_1f0._0_4_ = local_220;
                  uStack_1f0._4_4_ = fStack_21c;
                  fStack_1dc = fStack_218;
                  uStack_1e8._4_4_ = local_220;
                  local_1e0 = fStack_21c;
                  fVar42 = fVar42 * fVar43;
                  fVar44 = fVar44 * fVar43;
                  local_178 = (float **)(ulonglong)(uint)fVar42;
                  uStack_170 = (code *)(ulonglong)(uint)fVar44;
                  local_168 = (float *)CONCAT44(fVar45,fVar44);
                  uStack_160 = CONCAT44(fVar50,fVar42);
                  local_138 = __xmm_00000000000000003de978d53e2e7d57;
                  fStack_130 = 0.0348;
                  local_f1 = 1;
                  DoorMeshInProgress::add_quad();
                  bVar15 = true;
                } while (uVar33 < uVar16);
              }
              if (__real_402ccccd < local_13c && local_108 == 1) {
                local_100 = (float *)CONCAT44(local_100._4_4_,fVar40);
                if (pfStack_318 == (float *)0x0) {
                  local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                  core::panicking::panic_bounds_check();
                }
                pfVar20 = local_320 + (longlong)pfStack_318 * 3;
                if (pfVar20 == (float *)&DAT_0000000c) {
                  local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                  core::option::unwrap_failed();
                }
                fVar48 = pfVar25[1];
                fVar43 = pfVar25[6];
                fVar42 = (float)uStack_2f8;
                fVar44 = pfVar20[-1] - local_320[2];
                fVar50 = pfVar20[-3] - *local_320;
                fVar45 = __real_3f800000 / SQRT(fVar50 * fVar50 + fVar44 * fVar44);
                local_208 = (undefined **)
                            CONCAT44(fVar45 * fVar50,
                                     (float)((uint)fVar45 ^ ___xmm_80000000800000008000000080000000)
                                     * fVar44);
                local_f1 = 1;
                ::utils::swizzlers::impl$0::x0y();
                local_2f0 = CONCAT44(0x3f000000,fVar48);
                local_2e8._0_4_ = fVar43;
                uStack_200 = (float *)(local_2e8 + 4);
                uStack_1f8 = (float *)0x0;
                uStack_1f0 = &local_328;
                uStack_1e8 = &local_260;
                local_1e0 = 0.0;
                puVar36 = &local_2f0;
                pfVar20 = (float *)0x0;
                if ((float *)&local_2f0 != uStack_200) {
                  do {
                    local_208 = (undefined **)((longlong)puVar36 + 4);
                    uStack_1f8 = (float *)((longlong)pfVar20 + 1);
                    local_f1 = 1;
                    core::ops::function::impls::impl$4::
                    call_once<tuple_<tuple_<usize,ref_<f32>_>_>,system_wall_constructor::construct_gates::door_mesh_gap::closure_env_0>
                              ();
                    if (local_1e0 == 1.4013e-45) {
                      fStack_1dc = fStack_1cc;
                      uStack_1d8._0_4_ = fStack_1c8;
                      uStack_1d8._4_4_ = fStack_1c4;
                      pfVar1 = (float *)CONCAT44(fStack_1c4,fStack_1c8);
                      local_1d0 = fStack_1c0;
                      pfVar20 = &fStack_21c;
                      fStack_1cc = fStack_21c;
                      fStack_1c8 = fStack_218;
                      fStack_1c4 = fStack_214;
                      fStack_1c0 = fStack_210;
                      pfVar21 = &fStack_218;
                      pfVar22 = &fStack_214;
                    }
                    else {
                      fStack_12c = fStack_21c;
                      fStack_128 = fStack_218;
                      fStack_124 = fStack_214;
                      fStack_120 = fStack_210;
                      fStack_130 = 1.4013e-45;
                      local_138 = (float *)&local_208;
                      local_f1 = 1;
                      itertools::tuple_impl::impl$31::
                      collect_from_iter_no_buf<tuple_<glam::f32::vec3::Vec3,f32>,core::iter::adapters::chain::Chain<core::iter::sources::once::Once<tuple_<glam::f32::vec3::Vec3,f32>_>,ref_mut_<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<f32>_>,system_wall_constructor::construct_gates::door_mesh_gap::closure_env_0>_>_>_>
                                ();
                      fStack_1c0 = (float)local_2b8;
                      local_1d0 = (float)uStack_2c8;
                      fStack_1cc = uStack_2c8._4_4_;
                      fStack_1c8 = SUB84(uStack_2c0,0);
                      fStack_1c4 = (float)((ulonglong)uStack_2c0 >> 0x20);
                      local_1e0 = SUB84(local_2d8,0);
                      fStack_1dc = (float)((ulonglong)local_2d8 >> 0x20);
                      uStack_1d8 = uStack_2d0;
                      pfVar20 = &fStack_1cc;
                      pfVar21 = &fStack_1c8;
                      pfVar22 = &fStack_1c4;
                      pfVar1 = uStack_2d0;
                      if (local_1e0 != 1.4013e-45) break;
                    }
                    fVar49 = fStack_1c0;
                    fVar46 = local_1d0;
                    fVar50 = fStack_1dc;
                    uStack_1d8._4_4_ = (float)((ulonglong)pfVar1 >> 0x20);
                    fVar47 = uStack_1d8._4_4_;
                    uStack_1d8._0_4_ = SUB84(pfVar1,0);
                    fVar45 = (float)uStack_1d8;
                    fVar48 = *pfVar20;
                    fVar43 = *pfVar21;
                    fVar44 = *pfVar22;
                    local_220 = local_1d0;
                    uStack_1d8 = pfVar1;
                    if ((local_1d0 < 0.0) || (__real_3f800000 < local_1d0)) {
                      local_138 = &local_220;
                      fStack_130 = 6.774544;
                      fStack_12c = 1.4013e-45;
                      local_2d8 = &anon_95101f4d2e0328d894274322bc39dc37_3_llvm_14090887955549727255
                      ;
                      uStack_2d0._0_4_ = 1.4013e-45;
                      uStack_2d0._4_4_ = 0.0;
                      local_2b8._0_4_ = 0.0;
                      local_2b8._4_4_ = 0.0;
                      uStack_2c8 = &local_138;
                      uStack_2c0 = (float **)0x1;
                      local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                      core::panicking::panic_fmt();
                    }
                    if (NAN(local_1d0)) {
                      local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                      core::panicking::panic();
                    }
                    local_f1 = 1;
                    ::utils::curve::Curve::
                    get_coord_at_u<glam::f32::vec3::Vec3,utils::curve::CurveCoordSemantic3D,utils::curve::curve_u::CurveU<utils::curve::CurveCoordSemantic3D>_>
                              ();
                    local_220 = fVar49;
                    if ((fVar49 < 0.0) || (__real_3f800000 < fVar49)) {
                      local_138 = &local_220;
                      fStack_130 = 6.774544;
                      fStack_12c = 1.4013e-45;
                      local_2d8 = &anon_95101f4d2e0328d894274322bc39dc37_3_llvm_14090887955549727255
                      ;
                      uStack_2d0._0_4_ = 1.4013e-45;
                      uStack_2d0._4_4_ = 0.0;
                      local_2b8._0_4_ = 0.0;
                      local_2b8._4_4_ = 0.0;
                      uStack_2c8 = &local_138;
                      uStack_2c0 = (float **)0x1;
                      local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                      core::panicking::panic_fmt();
                    }
                    if (NAN(fVar49)) {
                      local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                      core::panicking::panic();
                    }
                    pfVar20 = (float *)(ulonglong)extraout_EAX_01;
                    local_f1 = 1;
                    ::utils::curve::Curve::
                    get_coord_at_u<glam::f32::vec3::Vec3,utils::curve::CurveCoordSemantic3D,utils::curve::curve_u::CurveU<utils::curve::CurveCoordSemantic3D>_>
                              ();
                    if (local_110 <= pfVar20) {
                      local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                      core::panicking::panic_bounds_check();
                    }
                    if (local_110 <= (float *)((longlong)pfVar20 + 1)) {
                      local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                      core::panicking::panic_bounds_check();
                    }
                    pfVar21 = (float *)(ulonglong)extraout_EAX_02;
                    if (local_110 <= pfVar21) {
                      local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                      core::panicking::panic_bounds_check();
                    }
                    if (local_110 <= (float *)((longlong)pfVar21 + 1)) {
                      local_f1 = 1;
                    /* WARNING: Subroutine does not return */
                      core::panicking::panic_bounds_check();
                    }
                    local_11c = (local_230[(longlong)((longlong)pfVar20 + 1)] -
                                local_230[(longlong)pfVar20]) * extraout_XMM0_Da_03 +
                                local_230[(longlong)pfVar20];
                    fStack_124 = (local_230[(longlong)((longlong)pfVar21 + 1)] -
                                 local_230[(longlong)pfVar21]) * extraout_XMM0_Da_04 +
                                 local_230[(longlong)pfVar21];
                    fStack_120 = fVar46 * fVar42;
                    fStack_130 = fVar49 * fVar42;
                    local_138 = (float *)(ulonglong)(uint)fStack_120;
                    fStack_12c = 0.0;
                    local_178 = (float **)CONCAT44(fVar45,fVar50);
                    uStack_170 = (code *)CONCAT44(fVar48,fVar47);
                    local_168 = (float *)CONCAT44(fVar44,fVar43);
                    uStack_160 = CONCAT44(fStack_124 + fVar43,fStack_124 * 0.0 + fVar48);
                    uStack_158 = CONCAT44(local_11c * 0.0 + fVar50,fStack_124 * 0.0 + fVar44);
                    uStack_150 = CONCAT44(local_11c * 0.0 + fVar47,local_11c + fVar45);
                    uStack_2d0._0_4_ = (float)local_258;
                    local_2d8 = (undefined **)local_260;
                    uStack_2c8._4_4_ = (float)local_258;
                    uStack_2d0._4_4_ = SUB84(local_260,0);
                    uStack_2c8._0_4_ = (float)((ulonglong)local_260 >> 0x20);
                    local_2b8._0_4_ = (float)local_258;
                    uStack_2c0 = (float **)local_260;
                    fStack_2ac = (float)local_258;
                    local_220 = (float)__xmm_00000000000000003d8831273dcb923a;
                    fStack_21c = (float)((ulonglong)__xmm_00000000000000003d8831273dcb923a >> 0x20);
                    fStack_218 = 0.020299999;
                    local_f1 = 1;
                    local_2b8._4_4_ = uStack_2d0._4_4_;
                    fStack_2b0 = (float)uStack_2c8;
                    fStack_128 = fStack_130;
                    DoorMeshInProgress::add_quad();
                    puVar36 = local_208;
                    pfVar20 = uStack_1f8;
                  } while (local_208 != (undefined **)uStack_200);
                }
                fVar40 = local_100._0_4_;
              }
              local_100 = (float *)0x0;
              local_118 = (float *)&DAT_00000004;
              local_f5 = 0;
              local_f6 = 1;
              local_f7 = 1;
              country_core::utils::geo::mesh_from_pts();
              local_2d8 = (undefined **)0x0;
              uStack_2d0._0_4_ = SUB84(local_118,0);
              uStack_2d0._4_4_ = (float)((ulonglong)local_118 >> 0x20);
              uStack_2c8._0_4_ = 0.0;
              uStack_2c8._4_4_ = 0.0;
              local_f3 = 1;
              local_f4 = 1;
              country_core::render::mesh::Mesh::
              set_attribute<alloc::vec::Vec<array_<f32,3>,alloc::alloc::Global>_>();
              local_2d8 = (undefined **)local_100;
              uStack_2d0._0_4_ = 5.60519e-45;
              uStack_2d0._4_4_ = 0.0;
              uStack_2c8._0_4_ = 0.0;
              uStack_2c8._4_4_ = 0.0;
              local_f3 = 0;
              local_f4 = 1;
              country_core::render::mesh::Mesh::
              set_attribute<alloc::vec::Vec<array_<f32,3>,alloc::alloc::Global>_>();
              local_2d8 = (undefined **)0x0;
              uStack_2d0._0_4_ = 5.60519e-45;
              uStack_2d0._4_4_ = 0.0;
              uStack_2c8._0_4_ = 0.0;
              uStack_2c8._4_4_ = 0.0;
              local_f3 = 0;
              local_f4 = 0;
              country_core::render::mesh::Mesh::
              set_attribute<alloc::vec::Vec<array_<f32,2>,alloc::alloc::Global>_>();
              uStack_2a0 = CONCAT44(fStack_1cc,local_1d0);
              local_298 = CONCAT44(fStack_1c4,fStack_1c8);
              local_288 = SUB84(pfStack_1b8,0);
              uStack_284 = (undefined4)((ulonglong)pfStack_1b8 >> 0x20);
              uStack_280 = SUB84(pvStack_1b0,0);
              uStack_27c = (undefined4)((ulonglong)pvStack_1b0 >> 0x20);
              uStack_2c0 = uStack_1f0;
              local_2a8 = uStack_1d8;
              local_268 = local_198;
              local_278 = local_1a8;
              uStack_28c = uStack_1bc;
              fStack_290 = fStack_1c0;
              fStack_2ac = fStack_1dc;
              fStack_2b0 = local_1e0;
              local_2b8 = uStack_1e8;
              uStack_2c8 = (float **)uStack_1f8;
              uStack_2d0 = uStack_200;
              local_2d8 = local_208;
              uStack_190 = 0x8000000000000000;
              local_f1 = 0;
              country_core::asset_libraries::mesh_library::AssetMeshLibrary::add();
              local_f1 = 0;
              pcVar29 = "solid_vertex_color_wooden_gate";
              country_core::asset_libraries::shader_library::AssetShaderLibrary::
              get_raster_handle_by_name();
              if ((extraout_RAX_07 & 1) == 0) {
                local_f1 = 0;
                    /* WARNING: Subroutine does not return */
                core::option::unwrap_failed();
              }
              local_f1 = 0;
              _ZN120__LT_bevy_ecs__system__schedule_system__InfallibleSystemWrapper_LT_S_GT__u20_as_u20_bevy_ecs__system__system__System_GT_16component_access17h024209426c3fd862E_llvm_6988214418030372215
                        ();
              local_f1 = 0;
              uVar30 = extraout_RAX_08;
              country_core::components::transient_mesh::TransientMesh::new_with_registry();
              fStack_130 = (float)uVar30;
              fVar48 = fStack_130;
              fStack_12c = (float)((ulonglong)uVar30 >> 0x20);
              fVar43 = fStack_12c;
              local_138 = extraout_RAX_09;
              minidump_unwind::instruction_seems_valid_by_symbols::async_fn$0::impl$0::
              get_instruction();
              pfVar20 = pfStack_318;
              if (local_110 < pfStack_318) {
                pfVar20 = local_110;
              }
              uStack_2d0 = local_320 + (longlong)pfStack_318 * 3;
              local_2d8 = (undefined **)local_320;
              uStack_2c8._0_4_ = SUB84(local_230,0);
              uStack_2c8._4_4_ = (float)((ulonglong)local_230 >> 0x20);
              local_2b8._0_4_ = 0.0;
              local_2b8._4_4_ = 0.0;
              fStack_2b0 = SUB84(pfVar20,0);
              fStack_2ac = (float)((ulonglong)pfVar20 >> 0x20);
              local_2a8 = pfStack_318;
              uStack_2c0 = (float **)pfVar24;
              alloc::vec::spec_from_iter::impl$0::
              from_iter<glam::f32::vec3::Vec3,core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<glam::f32::vec3::Vec3>,core::slice::iter::Iter<f32>_>,system_wall_constructor::construct_gates::construct_wooden_gate_doors::closure_env_0>_>
                        ();
              if (lVar6 == 0) {
                    /* WARNING: Subroutine does not return */
                core::panicking::panic_bounds_check();
              }
              ::utils::curve::Curve::
              get_coord_at_u<glam::f32::vec3::Vec3,utils::curve::CurveCoordSemantic3D,utils::curve::curve_u::CurveU<utils::curve::CurveCoordSemantic3D>_>
                        ();
              uVar33 = (ulonglong)extraout_EAX_04;
              uVar16 = uVar33 + 1;
              if (*(ulonglong *)(in_RDX + 0x26) <= uVar16) {
                    /* WARNING: Subroutine does not return */
                core::panicking::panic_bounds_check();
              }
              if (lVar17 + -4 + lVar6 * 4 == 0) {
                    /* WARNING: Subroutine does not return */
                core::option::unwrap_failed();
              }
              lVar7 = *(longlong *)(in_RDX + 0x24);
              fVar47 = *(float *)(lVar7 + 4 + uVar16 * 0xc) - *(float *)(lVar7 + 4 + uVar33 * 0xc);
              fVar42 = *(float *)(lVar7 + 8 + uVar16 * 0xc);
              fVar44 = *(float *)(lVar7 + uVar16 * 0xc);
              fVar50 = *(float *)(lVar7 + uVar33 * 0xc);
              fVar45 = *(float *)(lVar7 + 8 + uVar33 * 0xc);
              ::utils::curve::Curve::
              get_coord_at_u<glam::f32::vec3::Vec3,utils::curve::CurveCoordSemantic3D,utils::curve::curve_u::CurveU<utils::curve::CurveCoordSemantic3D>_>
                        ();
              uVar33 = (ulonglong)extraout_EAX_05;
              uVar16 = uVar33 + 1;
              if (*(ulonglong *)(in_RDX + 0x26) <= uVar16) {
                    /* WARNING: Subroutine does not return */
                core::panicking::panic_bounds_check();
              }
              lVar7 = *(longlong *)(in_RDX + 0x24);
              fVar46 = *(float *)(lVar7 + 4 + uVar16 * 0xc) - *(float *)(lVar7 + 4 + uVar33 * 0xc);
              local_188 = (int)local_108 + extraout_EAX_03 * in_stack_00000060;
              local_184 = *(undefined1 *)((longlong)in_RDX + 0x29a);
              local_1a8 = local_168;
              pfStack_1b8 = (float *)local_178;
              pvStack_1b0 = uStack_170;
              uStack_1f8._0_4_ = (float)__xmm_3f800000000000000000000000000000;
              uStack_1f8._4_4_ = (float)((ulonglong)__xmm_3f800000000000000000000000000000 >> 0x20);
              uStack_1f0._0_4_ = (float)DAT_14293e0c8;
              uStack_1f0._4_4_ = (float)((ulonglong)DAT_14293e0c8 >> 0x20);
              local_1e0 = 0.0;
              uStack_1e8._0_4_ = 0.0;
              uStack_1e8._4_4_ = 0.0;
              fStack_1dc = 1.0;
              uStack_1d8._0_4_ = 1.0;
              uStack_1d8._4_4_ = 1.0;
              fStack_1c8 = (float)extraout_RAX_06;
              fStack_1c4 = (float)((ulonglong)extraout_RAX_06 >> 0x20);
              fStack_1c0 = SUB84(pcVar29,0);
              uStack_1bc = (undefined4)((ulonglong)pcVar29 >> 0x20);
              fVar44 = fVar44 - fVar50;
              fVar42 = fVar42 - fVar45;
              fVar50 = __real_3f800000 / SQRT(fVar42 * fVar42 + fVar47 * fVar47 + fVar44 * fVar44);
              fVar44 = fVar50 * fVar44;
              fVar50 = fVar50 * fVar42;
              fVar42 = __real_3f800000 / SQRT(fVar50 * fVar50 + fVar44 * fVar44);
              local_198 = CONCAT44(fVar42 * fVar50,fVar42 * fVar44);
              fVar42 = *(float *)(lVar7 + uVar16 * 0xc) - *(float *)(lVar7 + uVar33 * 0xc);
              fVar50 = *(float *)(lVar7 + 8 + uVar16 * 0xc) - *(float *)(lVar7 + 8 + uVar33 * 0xc);
              fVar44 = __real_3f800000 / SQRT(fVar50 * fVar50 + fVar46 * fVar46 + fVar42 * fVar42);
              fVar42 = fVar44 * fVar42;
              fVar44 = fVar44 * fVar50;
              fVar50 = __real_3f800000 / SQRT(fVar44 * fVar44 + fVar42 * fVar42);
              uStack_190 = CONCAT44(fVar50 * fVar44,fVar50 * fVar42);
              local_f1 = 0;
              local_208 = (undefined **)extraout_RAX_09;
              uStack_200._0_4_ = fVar48;
              uStack_200._4_4_ = fVar43;
              bevy_ecs::system::commands::Commands::
              spawn<tuple_<country_core::components::drawable::DrawableMeshBundle,country_core::components::transient_mesh::TransientMesh,country_core::components::WoodenGate>_>
                        ();
              lVar7 = local_238;
              uVar30 = CONCAT44(local_2b8._4_4_,(float)local_2b8);
              if (local_238 == local_248) {
                local_f1 = 0;
                alloc::raw_vec::RawVec::grow_one<usize,alloc::alloc::Global>();
              }
              *(undefined8 *)(lStack_240 + lVar7 * 8) = uVar30;
              local_238 = lVar7 + 1;
              pfVar39 = pfVar39 + 6;
              pfVar20 = local_110;
              local_108 = uVar19;
            }
            std::alloc::__default_lib_allocator::__rust_dealloc();
            if (pfStack_318 == (float *)0x0) {
                    /* WARNING: Subroutine does not return */
              core::panicking::panic_bounds_check();
            }
            pfVar25 = local_320 + (longlong)pfStack_318 * 3;
            if (pfVar25 == (float *)&DAT_0000000c) {
                    /* WARNING: Subroutine does not return */
              core::option::unwrap_failed();
            }
            fVar42 = pfVar25[-3] - *local_320;
            fVar48 = pfVar25[-1] - local_320[2];
            fVar43 = __real_3f800000 /
                     SQRT(fVar48 * fVar48 +
                          (pfVar25[-2] - local_320[1]) * (pfVar25[-2] - local_320[1]) +
                          fVar42 * fVar42);
            fVar42 = fVar42 * fVar43;
            fVar43 = fVar43 * fVar48;
            local_208 = (undefined **)
                        CONCAT44(fVar42,___xmm_80000000800000008000000080000000 ^ (uint)fVar43);
            ::utils::swizzlers::impl$0::x0y();
            if (pfVar20 == (float *)0x0) {
              fVar48 = 0.0;
            }
            else {
              fVar48 = 0.0;
              pfVar20 = local_230;
              do {
                fVar44 = *pfVar20;
                pfVar20 = pfVar20 + 1;
                fVar50 = fVar44;
                if (fVar44 <= fVar48) {
                  fVar50 = fVar48;
                }
                fVar48 = (float)(~-(uint)NAN(fVar48) & (uint)fVar50 |
                                -(uint)NAN(fVar48) & (uint)fVar44);
                local_430 = local_430 + -4;
              } while (local_430 != 0);
            }
            fVar48 = fVar48 * __real_3ecccccd + ___real_be6b851f;
            if (local_13c <= __real_402ccccd) {
              ::utils::curve::Curve::
              get_coord_at_u<glam::f32::vec3::Vec3,utils::curve::CurveCoordSemantic3D,utils::curve::curve_u::CurveU<utils::curve::CurveCoordSemantic3D>_>
                        ();
              pfVar20 = (float *)(ulonglong)extraout_EAX_07;
              if (pfStack_318 <= pfVar20) {
                    /* WARNING: Subroutine does not return */
                core::panicking::panic_bounds_check();
              }
              pfVar25 = (float *)((longlong)pfVar20 + 1);
              if (pfStack_318 <= pfVar25) {
                    /* WARNING: Subroutine does not return */
                core::panicking::panic_bounds_check();
              }
              fVar43 = local_320[(longlong)pfVar20 * 3 + 2];
              fVar44 = (float)*(undefined8 *)(local_320 + (longlong)pfVar20 * 3);
              fVar50 = (float)((ulonglong)*(undefined8 *)(local_320 + (longlong)pfVar20 * 3) >> 0x20
                              );
              uVar30 = *(undefined8 *)(local_320 + (longlong)pfVar25 * 3);
              fVar42 = local_320[(longlong)pfVar25 * 3 + 2];
              std::alloc::__default_lib_allocator::__rust_alloc();
              if (extraout_RAX_11 == (float *)0x0) {
                    /* WARNING: Subroutine does not return */
                alloc::alloc::handle_alloc_error();
              }
              *(ulonglong *)extraout_RAX_11 =
                   CONCAT44(fVar48 + extraout_XMM0_Da_06 *
                                     ((float)((ulonglong)uVar30 >> 0x20) - fVar50) + fVar50,
                            fVar48 * 0.0 + extraout_XMM0_Da_06 * ((float)uVar30 - fVar44) + fVar44);
              extraout_RAX_11[2] = (fVar42 - fVar43) * extraout_XMM0_Da_06 + fVar43 + fVar48 * 0.0;
              local_100 = (float *)0x1;
              local_110 = extraout_RAX_11;
            }
            else {
              ::utils::curve::Curve::
              get_coord_at_u<glam::f32::vec3::Vec3,utils::curve::CurveCoordSemantic3D,utils::curve::curve_u::CurveU<utils::curve::CurveCoordSemantic3D>_>
                        ();
              pfVar20 = (float *)(ulonglong)extraout_EAX_06;
              if (pfStack_318 <= pfVar20) {
                    /* WARNING: Subroutine does not return */
                core::panicking::panic_bounds_check();
              }
              pfVar25 = (float *)((longlong)pfVar20 + 1);
              if (pfStack_318 <= pfVar25) {
                    /* WARNING: Subroutine does not return */
                core::panicking::panic_bounds_check();
              }
              fVar44 = local_320[(longlong)pfVar20 * 3 + 2];
              fVar50 = local_320[(longlong)pfVar25 * 3 + 2];
              fVar47 = (float)*(undefined8 *)(local_320 + (longlong)pfVar20 * 3);
              fVar46 = (float)((ulonglong)*(undefined8 *)(local_320 + (longlong)pfVar20 * 3) >> 0x20
                              );
              uVar30 = *(undefined8 *)(local_320 + (longlong)pfVar25 * 3);
              local_2d8 = (undefined **)CONCAT44(fVar43,fVar42);
              ::utils::swizzlers::impl$0::x0y();
              fVar45 = (float)uStack_200;
              pfVar20 = (float *)local_208;
              local_2d8 = (undefined **)CONCAT44(fVar43,fVar42);
              ::utils::swizzlers::impl$0::x0y();
              fVar43 = (float)uStack_200;
              fVar42 = SUB84(local_208,0);
              uVar16 = (ulonglong)local_208 >> 0x20;
              std::alloc::__default_lib_allocator::__rust_alloc();
              if (extraout_RAX_10 == (float *)0x0) {
                    /* WARNING: Subroutine does not return */
                alloc::alloc::handle_alloc_error();
              }
              fVar47 = extraout_XMM0_Da_05 * ((float)uVar30 - fVar47) + fVar47;
              fVar46 = extraout_XMM0_Da_05 * ((float)((ulonglong)uVar30 >> 0x20) - fVar46) + fVar46;
              fVar44 = (fVar50 - fVar44) * extraout_XMM0_Da_05 + fVar44;
              fVar45 = fVar45 * __real_3e800000;
              fVar50 = fVar48 * 0.0;
              fVar43 = fVar43 * __real_be800000;
              fVar42 = fVar42 * ___xmm_0000000000000000be800000be800000;
              fVar49 = (float)uVar16 * _UNK_142c1be74;
              *(ulonglong *)extraout_RAX_10 =
                   CONCAT44((float)((ulonglong)pfVar20 >> 0x20) * _UNK_142925944 + fVar48 + fVar46,
                            SUB84(pfVar20,0) * ___xmm_00000000000000003e8000003e800000 + fVar50 +
                            fVar47);
              extraout_RAX_10[2] = fVar45 + fVar50 + fVar44;
              *(ulonglong *)(extraout_RAX_10 + 3) =
                   CONCAT44(fVar49 + fVar48 + fVar46,fVar42 + fVar50 + fVar47);
              extraout_RAX_10[5] = fVar43 + fVar50 + fVar44;
              local_100 = (float *)0x2;
              local_110 = extraout_RAX_10;
            }
            iVar10 = (int)local_100;
            lVar18 = 0;
            do {
              uVar5 = *(undefined4 *)((longlong)local_110 + lVar18 + 8);
              uVar30 = *(undefined8 *)((longlong)local_110 + lVar18);
              ::utils::xz_rotation_bad();
              pfVar20 = (float *)local_208;
              uVar4 = CONCAT44(uStack_200._4_4_,(float)uStack_200);
              bevy_app::plugin::Plugin::finish<country_core::systems::main_camera::MainCameraPlugin>
                        ();
              bevy_ecs::system::commands::Commands::spawn_empty();
              pfVar25 = (float *)CONCAT44(uStack_200._4_4_,(float)uStack_200);
              if ((float *)CONCAT44(uStack_200._4_4_,(float)uStack_200) == (float *)0x0) {
                pfVar25 = uStack_1f8;
              }
              uVar14 = CONCAT44(uStack_1e8._4_4_,(float)uStack_1e8);
              lVar17 = *(longlong *)(pfVar25 + 4);
              if ((ulonglong)(*(longlong *)pfVar25 - lVar17) < 0x88) {
                alloc::raw_vec::impl$4::reserve::do_reserve_and_handle<alloc::alloc::Global>();
              }
              lVar7 = local_238;
              lVar6 = *(longlong *)(pfVar25 + 2);
              *(code **)(lVar6 + lVar17) =
                   core::ops::function::FnOnce::
                   call_once<bevy_ecs::world::command_queue::impl_4::push::closure_env_0<bevy_ecs::error::command_handling::impl_0::handle_error_with::closure_env_0<bevy_ecs::error::command_handling::impl_3::with_entity::closure_env_0<bevy_ecs::system::commands::entity_command::insert::closure_env_0<country_core::components::drawable::NaniBundle<country_core::render::nani::instance_data::SolidVertexColorInstanceData>_>_>,tuple_<>,enum2_<bevy_ecs::world::error::EntityMutableFetchError>_>_>,tuple_<bevy_ptr::OwningPtr<bevy_ptr::Unaligned>,enum2_<core::option::Option<core::ptr::non_null::NonNull<bevy_ecs::world::World>_>_>,ref_mut_<usize>_>_>
              ;
              puVar36 = (undefined8 *)(lVar6 + 8 + lVar17);
              *puVar36 = pfVar20;
              puVar36[1] = uVar4;
              *(undefined8 *)(lVar6 + 0x18 + lVar17) = uVar30;
              *(undefined4 *)(lVar6 + 0x20 + lVar17) = uVar5;
              *(undefined8 *)(lVar6 + 0x24 + lVar17) = 0x3f8000003f800000;
              *(undefined4 *)(lVar6 + 0x2c + lVar17) = 0x3f800000;
              *(undefined4 *)(lVar6 + 0x38 + lVar17) = 0;
              *(undefined8 *)(lVar6 + 0x40 + lVar17) = 0xb75231fda9a1fa83;
              *(undefined1 *)(lVar6 + 0x48 + lVar17) = 3;
              *(undefined1 *)(lVar6 + 0x58 + lVar17) = 0;
              *(undefined8 *)(lVar6 + 0x68 + lVar17) = uVar14;
              *(code **)(lVar6 + 0x78 + lVar17) = bevy_ecs::error::handler::panic;
              *(longlong *)(pfVar25 + 4) = lVar17 + 0x88;
              if (local_238 == local_248) {
                alloc::raw_vec::RawVec::grow_one<usize,alloc::alloc::Global>();
              }
              *(undefined8 *)(lStack_240 + lVar7 * 8) = uVar14;
              local_238 = lVar7 + 1;
              lVar18 = lVar18 + 0xc;
            } while ((ulonglong)(uint)(iVar10 * 4) * 3 != lVar18);
            std::alloc::__default_lib_allocator::__rust_dealloc();
            pfVar25 = local_228;
          }
          in_RCX[2] = local_238;
          *in_RCX = local_248;
          in_RCX[1] = lStack_240;
          if (pfVar25 != (float *)0x0) {
            std::alloc::__default_lib_allocator::__rust_dealloc();
          }
          if (local_328 != (float *)0x0) {
            std::alloc::__default_lib_allocator::__rust_dealloc();
          }
        }
        if (local_310 != 0) {
          std::alloc::__default_lib_allocator::__rust_dealloc();
        }
        return;
      }
      if ((float **)local_168 == local_178) {
        alloc::raw_vec::RawVec::grow_one<glam::f32::vec3::Vec3,alloc::alloc::Global>();
      }
      pfVar20 = pfVar22 + 3;
      pfVar39 = (float *)((longlong)pfVar39 + 1);
      *(ulonglong *)((longlong)uStack_170 + (longlong)pfVar25 * 0xc) =
           CONCAT44(fVar51 * fVar49 + fVar41 * fVar49,fVar40);
      *(float *)((longlong)uStack_170 + (longlong)pfVar25 * 0xc + 8) =
           fVar51 * fVar46 + fVar47 * fVar41;
      local_168 = (float *)((longlong)pfVar25 + 1);
    } while (pfVar24 <= pfVar39);
    fVar50 = fVar50 + SQRT((local_118[(longlong)pfVar39 * 3 + 2] - pfVar22[2]) *
                           (local_118[(longlong)pfVar39 * 3 + 2] - pfVar22[2]) +
                           (local_118[(longlong)pfVar39 * 3 + 1] - pfVar22[1]) *
                           (local_118[(longlong)pfVar39 * 3 + 1] - pfVar22[1]) +
                           (local_118[(longlong)pfVar39 * 3] - *pfVar22) *
                           (local_118[(longlong)pfVar39 * 3] - *pfVar22));
  } while( true );
}

