
/* WARNING: Removing unreachable block (ram,0x00014075589f) */

void __cdecl system_wall_constructor::construct_gates::systems::update_gates_hashmap(void)

{
  char *pcVar1;
  ulonglong *puVar2;
  undefined4 *puVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  ulonglong extraout_RAX;
  longlong lVar14;
  ulonglong uVar15;
  undefined1 (*extraout_RAX_00) [16];
  undefined1 (*pauVar16) [16];
  ulonglong extraout_RAX_01;
  ulonglong extraout_RAX_02;
  undefined8 *in_RCX;
  undefined7 uVar19;
  ulonglong *puVar17;
  undefined1 (*pauVar18) [16];
  undefined8 *in_RDX;
  undefined1 (*pauVar20) [16];
  undefined1 (*pauVar21) [16];
  undefined1 (*pauVar22) [16];
  undefined1 (*pauVar23) [16];
  undefined8 *in_R8;
  ulonglong uVar24;
  ulonglong uVar25;
  ushort uVar26;
  undefined8 *in_R9;
  undefined1 (*pauVar27) [16];
  ulonglong uVar28;
  longlong lVar29;
  undefined1 (*pauVar30) [16];
  longlong lVar31;
  undefined1 (*pauVar32) [16];
  undefined8 *puVar33;
  undefined1 (*pauVar34) [16];
  byte bVar35;
  byte bVar36;
  char cVar37;
  char cVar39;
  char cVar40;
  char cVar41;
  undefined1 auVar38 [16];
  undefined1 auVar42 [16];
  undefined1 auVar43 [16];
  undefined1 auVar44 [16];
  undefined1 auVar45 [16];
  undefined1 auVar46 [16];
  undefined1 auVar47 [16];
  undefined1 unaff_XMM6_Ba;
  undefined1 unaff_XMM6_Bb;
  undefined1 unaff_XMM6_Bc;
  undefined1 unaff_XMM6_Bd;
  undefined1 unaff_XMM6_Be;
  undefined1 unaff_XMM6_Bf;
  undefined1 unaff_XMM6_Bg;
  undefined1 unaff_XMM6_Bh;
  undefined1 unaff_XMM6_Bi;
  undefined1 unaff_XMM6_Bj;
  undefined1 unaff_XMM6_Bk;
  undefined1 unaff_XMM6_Bl;
  undefined1 unaff_XMM6_Bm;
  undefined1 unaff_XMM6_Bn;
  undefined1 unaff_XMM6_Bo;
  undefined1 unaff_XMM6_Bp;
  undefined8 *in_stack_00000028;
  undefined8 *in_stack_00000030;
  undefined8 *in_stack_00000038;
  undefined1 (*local_118) [16];
  undefined8 *local_e0;
  longlong local_d8;
  undefined8 local_d0;
  undefined8 local_c8;
  undefined1 (*local_c0) [16];
  ulonglong *local_b8;
  undefined1 (*local_b0) [16];
  ulonglong *local_a8;
  undefined4 local_9c;
  undefined1 (*local_98) [16];
  undefined1 (*local_90) [16];
  undefined8 *local_88;
  undefined1 (*local_80) [16];
  ulonglong local_78;
  undefined1 (*local_70) [16];
  ulonglong *local_68;
  undefined8 local_60;
  
  local_60 = 0xfffffffffffffffe;
  local_68 = (ulonglong *)*in_RCX;
  lVar31 = in_RCX[1];
  uVar25 = *local_68;
  uVar24 = 0;
  uVar15 = uVar25 - *(ulonglong *)(lVar31 + 0x18);
  if (uVar25 < *(ulonglong *)(lVar31 + 0x18)) {
    uVar15 = uVar24;
  }
  uVar28 = uVar25 - *(ulonglong *)(lVar31 + 0x38);
  if (uVar25 < *(ulonglong *)(lVar31 + 0x38)) {
    uVar28 = uVar24;
  }
  local_80 = (undefined1 (*) [16])(uVar15 * 0x10 + *(longlong *)(lVar31 + 8));
  uVar25 = *(ulonglong *)(lVar31 + 0x10) - uVar15;
  if (*(ulonglong *)(lVar31 + 0x10) < uVar15) {
    local_80 = (undefined1 (*) [16])&DAT_00000008;
    uVar25 = uVar24;
  }
  local_118 = (undefined1 (*) [16])(uVar28 * 0x10 + *(longlong *)(lVar31 + 0x28));
  uVar15 = *(ulonglong *)(lVar31 + 0x30) - uVar28;
  if (*(ulonglong *)(lVar31 + 0x30) < uVar28) {
    local_118 = (undefined1 (*) [16])&DAT_00000008;
    uVar15 = uVar24;
  }
  *local_68 = (*(longlong *)(lVar31 + 0x40) - uVar15) - uVar25;
  pauVar23 = local_80 + uVar25;
  pauVar21 = local_118 + uVar15;
  puVar2 = (ulonglong *)*in_RDX;
  lVar31 = in_RDX[1];
  uVar25 = *puVar2;
  uVar15 = uVar25 - *(ulonglong *)(lVar31 + 0x18);
  if (uVar25 < *(ulonglong *)(lVar31 + 0x18)) {
    uVar15 = uVar24;
  }
  uVar28 = uVar25 - *(ulonglong *)(lVar31 + 0x38);
  if (uVar25 < *(ulonglong *)(lVar31 + 0x38)) {
    uVar28 = uVar24;
  }
  pauVar34 = (undefined1 (*) [16])(uVar15 * 0x40 + *(longlong *)(lVar31 + 8));
  uVar25 = *(ulonglong *)(lVar31 + 0x10) - uVar15;
  if (*(ulonglong *)(lVar31 + 0x10) < uVar15) {
    pauVar34 = (undefined1 (*) [16])&DAT_00000008;
    uVar25 = uVar24;
  }
  pauVar32 = (undefined1 (*) [16])(uVar28 * 0x40 + *(longlong *)(lVar31 + 0x28));
  uVar15 = *(ulonglong *)(lVar31 + 0x30) - uVar28;
  if (*(ulonglong *)(lVar31 + 0x30) < uVar28) {
    pauVar32 = (undefined1 (*) [16])&DAT_00000008;
    uVar15 = uVar24;
  }
  *puVar2 = (*(longlong *)(lVar31 + 0x40) - uVar15) - uVar25;
  pauVar22 = pauVar34 + uVar25 * 4;
  pauVar30 = pauVar32 + uVar15 * 4;
  local_a8 = (ulonglong *)*in_R8;
  lVar31 = in_R8[1];
  uVar25 = *local_a8;
  uVar15 = uVar25 - *(ulonglong *)(lVar31 + 0x18);
  if (uVar25 < *(ulonglong *)(lVar31 + 0x18)) {
    uVar15 = uVar24;
  }
  uVar28 = uVar25 - *(ulonglong *)(lVar31 + 0x38);
  if (uVar25 < *(ulonglong *)(lVar31 + 0x38)) {
    uVar28 = uVar24;
  }
  local_70 = (undefined1 (*) [16])(uVar15 * 0x20 + *(longlong *)(lVar31 + 8));
  uVar25 = *(ulonglong *)(lVar31 + 0x10) - uVar15;
  if (*(ulonglong *)(lVar31 + 0x10) < uVar15) {
    local_70 = (undefined1 (*) [16])&DAT_00000008;
    uVar25 = uVar24;
  }
  local_98 = (undefined1 (*) [16])(uVar28 * 0x20 + *(longlong *)(lVar31 + 0x28));
  uVar15 = *(ulonglong *)(lVar31 + 0x30) - uVar28;
  if (*(ulonglong *)(lVar31 + 0x30) < uVar28) {
    local_98 = (undefined1 (*) [16])&DAT_00000008;
    uVar15 = uVar24;
  }
  *local_a8 = (*(longlong *)(lVar31 + 0x40) - uVar15) - uVar25;
  pauVar20 = local_70 + uVar25 * 2;
  pauVar27 = local_98 + uVar15 * 2;
  local_9c = *(undefined4 *)((longlong)in_stack_00000030 + 0x1c);
  pauVar18 = (undefined1 (*) [16])*in_stack_00000030;
  puVar3 = (undefined4 *)in_stack_00000030[2];
  puVar4 = (undefined8 *)*in_stack_00000038;
  lVar31 = in_stack_00000038[1];
  uVar5 = in_stack_00000038[3];
  uVar6 = in_stack_00000038[2];
  iVar8 = -(uint)(CONCAT13(unaff_XMM6_Bd,
                           CONCAT12(unaff_XMM6_Bc,CONCAT11(unaff_XMM6_Bb,unaff_XMM6_Ba))) ==
                 CONCAT13(unaff_XMM6_Bd,
                          CONCAT12(unaff_XMM6_Bc,CONCAT11(unaff_XMM6_Bb,unaff_XMM6_Ba))));
  iVar9 = -(uint)(CONCAT13(unaff_XMM6_Bh,
                           CONCAT12(unaff_XMM6_Bg,CONCAT11(unaff_XMM6_Bf,unaff_XMM6_Be))) ==
                 CONCAT13(unaff_XMM6_Bh,
                          CONCAT12(unaff_XMM6_Bg,CONCAT11(unaff_XMM6_Bf,unaff_XMM6_Be))));
  iVar10 = -(uint)(CONCAT13(unaff_XMM6_Bl,
                            CONCAT12(unaff_XMM6_Bk,CONCAT11(unaff_XMM6_Bj,unaff_XMM6_Bi))) ==
                  CONCAT13(unaff_XMM6_Bl,
                           CONCAT12(unaff_XMM6_Bk,CONCAT11(unaff_XMM6_Bj,unaff_XMM6_Bi))));
  iVar11 = -(uint)(CONCAT13(unaff_XMM6_Bp,
                            CONCAT12(unaff_XMM6_Bo,CONCAT11(unaff_XMM6_Bn,unaff_XMM6_Bm))) ==
                  CONCAT13(unaff_XMM6_Bp,
                           CONCAT12(unaff_XMM6_Bo,CONCAT11(unaff_XMM6_Bn,unaff_XMM6_Bm))));
  pauVar16 = pauVar18 + 2;
  local_b0 = pauVar16;
  local_90 = pauVar18;
LAB_140755900:
  if (local_68 != (ulonglong *)0x0) {
    if ((local_80 != (undefined1 (*) [16])0x0) && (local_80 != pauVar23)) {
      local_78 = CONCAT71((int7)((ulonglong)pauVar16 >> 8),1);
      pauVar16 = local_80;
      puVar17 = local_68;
      local_80 = local_80 + 1;
      goto LAB_140755a6b;
    }
    pauVar18 = local_118;
    if (local_118 == (undefined1 (*) [16])0x0) {
      local_80 = (undefined1 (*) [16])0x0;
    }
    else {
      local_80 = (undefined1 (*) [16])0x0;
      if (local_118 != pauVar21) {
        local_78 = 1;
        local_80 = (undefined1 (*) [16])0x0;
        pauVar16 = local_118;
        puVar17 = local_68;
        local_118 = local_118 + 1;
        goto LAB_140755a6b;
      }
    }
  }
  uVar19 = (undefined7)((ulonglong)pauVar18 >> 8);
  puVar17 = puVar2;
  if ((pauVar34 != (undefined1 (*) [16])0x0) && (pauVar34 != pauVar22)) {
    local_78 = CONCAT71(uVar19,1);
    local_68 = (ulonglong *)0x0;
    pauVar16 = pauVar34;
    pauVar34 = pauVar34 + 4;
    goto LAB_140755a6b;
  }
  if ((pauVar32 != (undefined1 (*) [16])0x0) && (pauVar32 != pauVar30)) {
    local_78 = CONCAT71(uVar19,1);
    pauVar34 = (undefined1 (*) [16])0x0;
    local_68 = (ulonglong *)0x0;
    pauVar16 = pauVar32;
    pauVar32 = pauVar32 + 4;
    goto LAB_140755a6b;
  }
  pauVar34 = (undefined1 (*) [16])0x0;
  local_68 = (ulonglong *)0x0;
  pauVar16 = local_98;
  if (local_70 != (undefined1 (*) [16])0x0) goto LAB_1407558d4;
LAB_140755a30:
  if ((pauVar16 == (undefined1 (*) [16])0x0) || (pauVar16 == pauVar27)) {
    local_68 = (ulonglong *)*in_R9;
    lVar29 = in_R9[1];
    uVar25 = *local_68;
    uVar24 = 0;
    uVar15 = uVar25 - *(ulonglong *)(lVar29 + 0x18);
    if (uVar25 < *(ulonglong *)(lVar29 + 0x18)) {
      uVar15 = uVar24;
    }
    uVar28 = uVar25 - *(ulonglong *)(lVar29 + 0x38);
    if (uVar25 < *(ulonglong *)(lVar29 + 0x38)) {
      uVar28 = uVar24;
    }
    local_80 = (undefined1 (*) [16])(uVar15 * 0x10 + *(longlong *)(lVar29 + 8));
    uVar25 = *(ulonglong *)(lVar29 + 0x10) - uVar15;
    if (*(ulonglong *)(lVar29 + 0x10) < uVar15) {
      local_80 = (undefined1 (*) [16])0x8;
      uVar25 = uVar24;
    }
    local_70 = (undefined1 (*) [16])(uVar28 * 0x10 + *(longlong *)(lVar29 + 0x28));
    uVar15 = *(ulonglong *)(lVar29 + 0x30) - uVar28;
    if (*(ulonglong *)(lVar29 + 0x30) < uVar28) {
      local_70 = (undefined1 (*) [16])0x8;
      uVar15 = uVar24;
    }
    *local_68 = (*(longlong *)(lVar29 + 0x40) - uVar15) - uVar25;
    local_b8 = (ulonglong *)(uVar25 * 0x10 + (longlong)local_80);
    local_a8 = (ulonglong *)(uVar15 * 0x10 + (longlong)local_70);
    local_98 = (undefined1 (*) [16])lVar31;
    do {
      if ((local_80 == (undefined1 (*) [16])0x0) || (local_80 == (undefined1 (*) [16])local_b8)) {
        if ((local_70 == (undefined1 (*) [16])0x0) || (local_70 == (undefined1 (*) [16])local_a8)) {
          local_b8 = (ulonglong *)*in_stack_00000028;
          lVar31 = in_stack_00000028[1];
          uVar25 = *local_b8;
          uVar24 = 0;
          uVar15 = uVar25 - *(ulonglong *)(lVar31 + 0x18);
          if (uVar25 < *(ulonglong *)(lVar31 + 0x18)) {
            uVar15 = uVar24;
          }
          uVar28 = uVar25 - *(ulonglong *)(lVar31 + 0x38);
          if (uVar25 < *(ulonglong *)(lVar31 + 0x38)) {
            uVar28 = uVar24;
          }
          local_68 = (ulonglong *)(uVar15 * 0x18 + *(longlong *)(lVar31 + 8));
          uVar25 = *(ulonglong *)(lVar31 + 0x10) - uVar15;
          if (*(ulonglong *)(lVar31 + 0x10) < uVar15) {
            local_68 = (ulonglong *)0x8;
            uVar25 = uVar24;
          }
          local_80 = (undefined1 (*) [16])(uVar28 * 0x18 + *(longlong *)(lVar31 + 0x28));
          uVar15 = *(ulonglong *)(lVar31 + 0x30) - uVar28;
          if (*(ulonglong *)(lVar31 + 0x30) < uVar28) {
            local_80 = (undefined1 (*) [16])0x8;
            uVar15 = uVar24;
          }
          *local_b8 = (*(longlong *)(lVar31 + 0x40) - uVar15) - uVar25;
          local_a8 = (ulonglong *)((longlong)local_68 + uVar25 * 0x18);
          lVar31 = (longlong)local_80 + uVar15 * 0x18;
          do {
            if ((local_68 == (ulonglong *)0x0) || (local_68 == local_a8)) {
              if ((local_80 == (undefined1 (*) [16])0x0) ||
                 (local_80 == (undefined1 (*) [16])lVar31)) {
                return;
              }
              local_68 = (ulonglong *)0x0;
              lVar29 = (longlong)local_80;
              local_80 = (undefined1 (*) [16])((longlong)local_80 + 0x18);
            }
            else {
              lVar29 = (longlong)local_68;
              local_68 = (ulonglong *)((longlong)local_68 + 0x18);
            }
            *local_b8 = *local_b8 + 1;
            pauVar23 = (undefined1 (*) [16])(lVar29 + 8);
            local_70 = pauVar23;
            if (*(longlong *)(local_90[1] + 8) != 0) {
              core::hash::BuildHasher::
              hash_one<std::hash::random::RandomState,ref_<country_core::systems::ui::GlobalId>_>();
              pauVar21 = local_98;
              lVar29 = *(longlong *)*local_90;
              bVar35 = (byte)(extraout_RAX_02 >> 0x39);
              auVar38 = ZEXT216(CONCAT11(bVar35,bVar35));
              auVar38 = pshuflw(auVar38,auVar38,0);
              lVar14 = 0;
              uVar25 = extraout_RAX_02;
              while( true ) {
                uVar25 = *(ulonglong *)(*local_90 + 8) & uVar25;
                pcVar1 = (char *)(lVar29 + uVar25);
                cVar37 = auVar38[0];
                auVar47[0] = -(*pcVar1 == cVar37);
                cVar39 = auVar38[1];
                auVar47[1] = -(pcVar1[1] == cVar39);
                cVar40 = auVar38[2];
                auVar47[2] = -(pcVar1[2] == cVar40);
                cVar41 = auVar38[3];
                auVar47[3] = -(pcVar1[3] == cVar41);
                auVar47[4] = -(pcVar1[4] == cVar37);
                auVar47[5] = -(pcVar1[5] == cVar39);
                auVar47[6] = -(pcVar1[6] == cVar40);
                auVar47[7] = -(pcVar1[7] == cVar41);
                auVar47[8] = -(pcVar1[8] == cVar37);
                auVar47[9] = -(pcVar1[9] == cVar39);
                auVar47[10] = -(pcVar1[10] == cVar40);
                auVar47[0xb] = -(pcVar1[0xb] == cVar41);
                auVar47[0xc] = -(pcVar1[0xc] == cVar37);
                auVar47[0xd] = -(pcVar1[0xd] == cVar39);
                auVar47[0xe] = -(pcVar1[0xe] == cVar40);
                auVar47[0xf] = -(pcVar1[0xf] == cVar41);
                uVar26 = (ushort)(SUB161(auVar47 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar47 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar47 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar47 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar47 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar47 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar47 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar47 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar47 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar47 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar47 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar47 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar47 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar47 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar47 >> 0x77,0) & 1) << 0xe |
                         (ushort)(auVar47[0xf] >> 7) << 0xf;
                uVar12 = (uint)uVar26;
                if (uVar26 != 0) {
                  do {
                    uVar13 = 0;
                    for (uVar7 = uVar12; (uVar7 & 1) == 0; uVar7 = uVar7 >> 1 | 0x80000000) {
                      uVar13 = uVar13 + 1;
                    }
                    uVar15 = uVar13 + uVar25 & *(ulonglong *)(*local_90 + 8);
                    if (*(longlong *)pauVar23 == *(longlong *)(lVar29 + -0x20 + uVar15 * -0x20)) {
                      lVar14 = uVar15 * -0x20;
                      local_88 = *(undefined8 **)(lVar29 + -8 + lVar14);
                      if (local_88 != (undefined8 *)0x0) {
                        local_78 = *(ulonglong *)(lVar29 + -0x10 + lVar14);
                        local_88 = (undefined8 *)((longlong)local_88 << 3);
                        puVar33 = (undefined8 *)0x0;
                        do {
                          local_c0 = *(undefined1 (**) [16])(local_78 + (longlong)puVar33);
                          local_d8 = (longlong)pauVar21;
                          local_e0 = puVar4;
                          local_d0 = uVar6;
                          local_c8 = uVar5;
                          bevy_ecs::system::commands::EntityCommands::despawn();
                          puVar33 = puVar33 + 1;
                        } while (local_88 != puVar33);
                      }
                      goto LAB_14075629d;
                    }
                    uVar26 = (ushort)(uVar12 - 1) & (ushort)uVar12;
                    uVar12 = CONCAT22((short)(uVar12 - 1 >> 0x10),uVar26);
                  } while (uVar26 != 0);
                }
                auVar44[0] = -(*pcVar1 == -1);
                auVar44[1] = -(pcVar1[1] == -1);
                auVar44[2] = -(pcVar1[2] == -1);
                auVar44[3] = -(pcVar1[3] == -1);
                auVar44[4] = -(pcVar1[4] == -1);
                auVar44[5] = -(pcVar1[5] == -1);
                auVar44[6] = -(pcVar1[6] == -1);
                auVar44[7] = -(pcVar1[7] == -1);
                auVar44[8] = -(pcVar1[8] == -1);
                auVar44[9] = -(pcVar1[9] == -1);
                auVar44[10] = -(pcVar1[10] == -1);
                auVar44[0xb] = -(pcVar1[0xb] == -1);
                auVar44[0xc] = -(pcVar1[0xc] == -1);
                auVar44[0xd] = -(pcVar1[0xd] == -1);
                auVar44[0xe] = -(pcVar1[0xe] == -1);
                auVar44[0xf] = -(pcVar1[0xf] == -1);
                if ((((((((((((((((SUB161(auVar44 >> 7,0) & 1) != 0 ||
                                 (SUB161(auVar44 >> 0xf,0) & 1) != 0) ||
                                (SUB161(auVar44 >> 0x17,0) & 1) != 0) ||
                               (SUB161(auVar44 >> 0x1f,0) & 1) != 0) ||
                              (SUB161(auVar44 >> 0x27,0) & 1) != 0) ||
                             (SUB161(auVar44 >> 0x2f,0) & 1) != 0) ||
                            (SUB161(auVar44 >> 0x37,0) & 1) != 0) ||
                           (SUB161(auVar44 >> 0x3f,0) & 1) != 0) ||
                          (SUB161(auVar44 >> 0x47,0) & 1) != 0) ||
                         (SUB161(auVar44 >> 0x4f,0) & 1) != 0) ||
                        (SUB161(auVar44 >> 0x57,0) & 1) != 0) ||
                       (SUB161(auVar44 >> 0x5f,0) & 1) != 0) || (SUB161(auVar44 >> 0x67,0) & 1) != 0
                      ) || (SUB161(auVar44 >> 0x6f,0) & 1) != 0) ||
                    (SUB161(auVar44 >> 0x77,0) & 1) != 0) || auVar44[0xf] < '\0') break;
                uVar25 = uVar25 + lVar14 + 0x10;
                lVar14 = lVar14 + 0x10;
                pauVar23 = local_70;
              }
            }
LAB_14075629d:
            *puVar3 = local_9c;
            core::hash::BuildHasher::
            hash_one<std::hash::random::RandomState,ref_<country_core::systems::ui::GlobalId>_>();
            hashbrown::raw::RawTable::
            remove_entry<tuple_<country_core::resources::walls::WallId,alloc::vec::Vec<bevy_ecs::entity::Entity,alloc::alloc::Global>_>,alloc::alloc::Global,hashbrown::map::equivalent_key::closure_env_0<country_core::resources::walls::WallId,country_core::resources::walls::WallId,alloc::vec::Vec<bevy_ecs::entity::Entity,alloc::alloc::Global>_>_>
                      ();
            if ((!SBORROW8(0,local_d8)) && (local_d8 != 0)) {
              std::alloc::__default_lib_allocator::__rust_dealloc();
            }
          } while( true );
        }
        local_80 = (undefined1 (*) [16])0x0;
        lVar31 = (longlong)local_70;
        local_70 = (undefined1 (*) [16])((longlong)local_70 + 0x10);
      }
      else {
        lVar31 = (longlong)local_80;
        local_80 = (undefined1 (*) [16])((longlong)local_80 + 0x10);
      }
      *local_68 = *local_68 + 1;
      lVar31 = *(longlong *)(lVar31 + 8);
      if (*(longlong *)(local_90[1] + 8) != 0) {
        core::hash::BuildHasher::
        hash_one<std::hash::random::RandomState,ref_<country_core::systems::ui::GlobalId>_>();
        pauVar23 = local_98;
        lVar29 = *(longlong *)*local_90;
        bVar35 = (byte)(extraout_RAX_01 >> 0x39);
        auVar38 = ZEXT216(CONCAT11(bVar35,bVar35));
        auVar38 = pshuflw(auVar38,auVar38,0);
        lVar14 = 0;
        uVar25 = extraout_RAX_01;
        while( true ) {
          uVar25 = *(ulonglong *)(*local_90 + 8) & uVar25;
          pcVar1 = (char *)(lVar29 + uVar25);
          cVar37 = auVar38[0];
          auVar46[0] = -(*pcVar1 == cVar37);
          cVar39 = auVar38[1];
          auVar46[1] = -(pcVar1[1] == cVar39);
          cVar40 = auVar38[2];
          auVar46[2] = -(pcVar1[2] == cVar40);
          cVar41 = auVar38[3];
          auVar46[3] = -(pcVar1[3] == cVar41);
          auVar46[4] = -(pcVar1[4] == cVar37);
          auVar46[5] = -(pcVar1[5] == cVar39);
          auVar46[6] = -(pcVar1[6] == cVar40);
          auVar46[7] = -(pcVar1[7] == cVar41);
          auVar46[8] = -(pcVar1[8] == cVar37);
          auVar46[9] = -(pcVar1[9] == cVar39);
          auVar46[10] = -(pcVar1[10] == cVar40);
          auVar46[0xb] = -(pcVar1[0xb] == cVar41);
          auVar46[0xc] = -(pcVar1[0xc] == cVar37);
          auVar46[0xd] = -(pcVar1[0xd] == cVar39);
          auVar46[0xe] = -(pcVar1[0xe] == cVar40);
          auVar46[0xf] = -(pcVar1[0xf] == cVar41);
          uVar26 = (ushort)(SUB161(auVar46 >> 7,0) & 1) |
                   (ushort)(SUB161(auVar46 >> 0xf,0) & 1) << 1 |
                   (ushort)(SUB161(auVar46 >> 0x17,0) & 1) << 2 |
                   (ushort)(SUB161(auVar46 >> 0x1f,0) & 1) << 3 |
                   (ushort)(SUB161(auVar46 >> 0x27,0) & 1) << 4 |
                   (ushort)(SUB161(auVar46 >> 0x2f,0) & 1) << 5 |
                   (ushort)(SUB161(auVar46 >> 0x37,0) & 1) << 6 |
                   (ushort)(SUB161(auVar46 >> 0x3f,0) & 1) << 7 |
                   (ushort)(SUB161(auVar46 >> 0x47,0) & 1) << 8 |
                   (ushort)(SUB161(auVar46 >> 0x4f,0) & 1) << 9 |
                   (ushort)(SUB161(auVar46 >> 0x57,0) & 1) << 10 |
                   (ushort)(SUB161(auVar46 >> 0x5f,0) & 1) << 0xb |
                   (ushort)(SUB161(auVar46 >> 0x67,0) & 1) << 0xc |
                   (ushort)(SUB161(auVar46 >> 0x6f,0) & 1) << 0xd |
                   (ushort)(SUB161(auVar46 >> 0x77,0) & 1) << 0xe |
                   (ushort)(auVar46[0xf] >> 7) << 0xf;
          uVar12 = (uint)uVar26;
          while (uVar26 != 0) {
            uVar13 = 0;
            for (uVar7 = uVar12; (uVar7 & 1) == 0; uVar7 = uVar7 >> 1 | 0x80000000) {
              uVar13 = uVar13 + 1;
            }
            uVar15 = uVar13 + uVar25 & *(ulonglong *)(*local_90 + 8);
            if (lVar31 == *(longlong *)(lVar29 + -0x20 + uVar15 * -0x20)) {
              lVar31 = uVar15 * -0x20;
              local_88 = *(undefined8 **)(lVar29 + -8 + lVar31);
              if (local_88 != (undefined8 *)0x0) {
                local_78 = *(ulonglong *)(lVar29 + -0x10 + lVar31);
                local_88 = (undefined8 *)((longlong)local_88 << 3);
                puVar33 = (undefined8 *)0x0;
                do {
                  local_c0 = *(undefined1 (**) [16])(local_78 + (longlong)puVar33);
                  local_d8 = (longlong)pauVar23;
                  local_e0 = puVar4;
                  local_d0 = uVar6;
                  local_c8 = uVar5;
                  bevy_ecs::system::commands::EntityCommands::despawn();
                  puVar33 = puVar33 + 1;
                } while (local_88 != puVar33);
              }
              goto LAB_140755fd7;
            }
            uVar26 = (ushort)(uVar12 - 1) & (ushort)uVar12;
            uVar12 = CONCAT22((short)(uVar12 - 1 >> 0x10),uVar26);
          }
          auVar43[0] = -(*pcVar1 == -1);
          auVar43[1] = -(pcVar1[1] == -1);
          auVar43[2] = -(pcVar1[2] == -1);
          auVar43[3] = -(pcVar1[3] == -1);
          auVar43[4] = -(pcVar1[4] == -1);
          auVar43[5] = -(pcVar1[5] == -1);
          auVar43[6] = -(pcVar1[6] == -1);
          auVar43[7] = -(pcVar1[7] == -1);
          auVar43[8] = -(pcVar1[8] == -1);
          auVar43[9] = -(pcVar1[9] == -1);
          auVar43[10] = -(pcVar1[10] == -1);
          auVar43[0xb] = -(pcVar1[0xb] == -1);
          auVar43[0xc] = -(pcVar1[0xc] == -1);
          auVar43[0xd] = -(pcVar1[0xd] == -1);
          auVar43[0xe] = -(pcVar1[0xe] == -1);
          auVar43[0xf] = -(pcVar1[0xf] == -1);
          if ((((((((((((((((SUB161(auVar43 >> 7,0) & 1) != 0 || (SUB161(auVar43 >> 0xf,0) & 1) != 0
                           ) || (SUB161(auVar43 >> 0x17,0) & 1) != 0) ||
                         (SUB161(auVar43 >> 0x1f,0) & 1) != 0) ||
                        (SUB161(auVar43 >> 0x27,0) & 1) != 0) ||
                       (SUB161(auVar43 >> 0x2f,0) & 1) != 0) || (SUB161(auVar43 >> 0x37,0) & 1) != 0
                      ) || (SUB161(auVar43 >> 0x3f,0) & 1) != 0) ||
                    (SUB161(auVar43 >> 0x47,0) & 1) != 0) || (SUB161(auVar43 >> 0x4f,0) & 1) != 0)
                  || (SUB161(auVar43 >> 0x57,0) & 1) != 0) || (SUB161(auVar43 >> 0x5f,0) & 1) != 0)
                || (SUB161(auVar43 >> 0x67,0) & 1) != 0) || (SUB161(auVar43 >> 0x6f,0) & 1) != 0) ||
              (SUB161(auVar43 >> 0x77,0) & 1) != 0) || auVar43[0xf] < '\0') break;
          uVar25 = uVar25 + lVar14 + 0x10;
          lVar14 = lVar14 + 0x10;
        }
      }
LAB_140755fd7:
      *puVar3 = local_9c;
      core::hash::BuildHasher::
      hash_one<std::hash::random::RandomState,ref_<country_core::systems::ui::GlobalId>_>();
      hashbrown::raw::RawTable::
      remove_entry<tuple_<country_core::resources::walls::WallId,alloc::vec::Vec<bevy_ecs::entity::Entity,alloc::alloc::Global>_>,alloc::alloc::Global,hashbrown::map::equivalent_key::closure_env_0<country_core::resources::walls::WallId,country_core::resources::walls::WallId,alloc::vec::Vec<bevy_ecs::entity::Entity,alloc::alloc::Global>_>_>
                ();
      if ((!SBORROW8(0,local_d8)) && (local_d8 != 0)) {
        std::alloc::__default_lib_allocator::__rust_dealloc();
      }
    } while( true );
  }
  local_98 = pauVar16 + 2;
  local_78 = 0;
  local_70 = (undefined1 (*) [16])0x0;
  puVar17 = local_a8;
LAB_140755a6b:
  *puVar17 = *puVar17 + 1;
  local_e0 = *(undefined8 **)(*pauVar16 + 8);
  *puVar3 = local_9c;
  local_88 = local_e0;
  core::hash::BuildHasher::
  hash_one<std::hash::random::RandomState,ref_<country_core::systems::ui::GlobalId>_>();
  pauVar16 = local_90;
  pauVar18 = *(undefined1 (**) [16])*local_90;
  uVar25 = *(ulonglong *)(*local_90 + 8);
  uVar24 = uVar25 & extraout_RAX;
  bVar35 = (byte)(extraout_RAX >> 0x38);
  bVar36 = bVar35 >> 1;
  auVar38 = ZEXT216(CONCAT11(bVar36,bVar36));
  auVar38 = pshuflw(auVar38,auVar38,0);
  lVar29 = 0;
  uVar15 = uVar24;
  while( true ) {
    pcVar1 = (char *)((longlong)*pauVar18 + uVar15);
    cVar37 = auVar38[0];
    auVar45[0] = -(*pcVar1 == cVar37);
    cVar39 = auVar38[1];
    auVar45[1] = -(pcVar1[1] == cVar39);
    cVar40 = auVar38[2];
    auVar45[2] = -(pcVar1[2] == cVar40);
    cVar41 = auVar38[3];
    auVar45[3] = -(pcVar1[3] == cVar41);
    auVar45[4] = -(pcVar1[4] == cVar37);
    auVar45[5] = -(pcVar1[5] == cVar39);
    auVar45[6] = -(pcVar1[6] == cVar40);
    auVar45[7] = -(pcVar1[7] == cVar41);
    auVar45[8] = -(pcVar1[8] == cVar37);
    auVar45[9] = -(pcVar1[9] == cVar39);
    auVar45[10] = -(pcVar1[10] == cVar40);
    auVar45[0xb] = -(pcVar1[0xb] == cVar41);
    auVar45[0xc] = -(pcVar1[0xc] == cVar37);
    auVar45[0xd] = -(pcVar1[0xd] == cVar39);
    auVar45[0xe] = -(pcVar1[0xe] == cVar40);
    auVar45[0xf] = -(pcVar1[0xf] == cVar41);
    uVar26 = (ushort)(SUB161(auVar45 >> 7,0) & 1) | (ushort)(SUB161(auVar45 >> 0xf,0) & 1) << 1 |
             (ushort)(SUB161(auVar45 >> 0x17,0) & 1) << 2 |
             (ushort)(SUB161(auVar45 >> 0x1f,0) & 1) << 3 |
             (ushort)(SUB161(auVar45 >> 0x27,0) & 1) << 4 |
             (ushort)(SUB161(auVar45 >> 0x2f,0) & 1) << 5 |
             (ushort)(SUB161(auVar45 >> 0x37,0) & 1) << 6 |
             (ushort)(SUB161(auVar45 >> 0x3f,0) & 1) << 7 |
             (ushort)(SUB161(auVar45 >> 0x47,0) & 1) << 8 |
             (ushort)(SUB161(auVar45 >> 0x4f,0) & 1) << 9 |
             (ushort)(SUB161(auVar45 >> 0x57,0) & 1) << 10 |
             (ushort)(SUB161(auVar45 >> 0x5f,0) & 1) << 0xb |
             (ushort)(SUB161(auVar45 >> 0x67,0) & 1) << 0xc |
             (ushort)(SUB161(auVar45 >> 0x6f,0) & 1) << 0xd |
             (ushort)(SUB161(auVar45 >> 0x77,0) & 1) << 0xe | (ushort)(auVar45[0xf] >> 7) << 0xf;
    uVar12 = (uint)uVar26;
    while (uVar26 != 0) {
      uVar13 = 0;
      for (uVar7 = uVar12; (uVar7 & 1) == 0; uVar7 = uVar7 >> 1 | 0x80000000) {
        uVar13 = uVar13 + 1;
      }
      uVar28 = uVar13 + uVar15 & uVar25;
      if (*(undefined8 **)pauVar18[uVar28 * -2 + -2] == local_88) {
        pauVar16 = (undefined1 (*) [16])((longlong)pauVar18[uVar28 * -2 + -2] + 8);
        puVar33 = *(undefined8 **)pauVar18[uVar28 * -2 + -1];
        lVar29 = *(longlong *)((longlong)pauVar18[uVar28 * -2 + -1] + 8);
        *(undefined8 *)((longlong)pauVar18[uVar28 * -2 + -1] + 8) = 0;
        pauVar18 = (undefined1 (*) [16])(puVar33 + lVar29);
        if (lVar29 == 0) goto LAB_1407558b0;
        lVar29 = lVar29 << 3;
        goto LAB_140755be0;
      }
      uVar26 = (ushort)(uVar12 - 1) & (ushort)uVar12;
      uVar12 = CONCAT22((short)(uVar12 - 1 >> 0x10),uVar26);
    }
    auVar42[0] = -(*pcVar1 == (char)iVar8);
    auVar42[1] = -(pcVar1[1] == (char)((uint)iVar8 >> 8));
    auVar42[2] = -(pcVar1[2] == (char)((uint)iVar8 >> 0x10));
    auVar42[3] = -(pcVar1[3] == (char)((uint)iVar8 >> 0x18));
    auVar42[4] = -(pcVar1[4] == (char)iVar9);
    auVar42[5] = -(pcVar1[5] == (char)((uint)iVar9 >> 8));
    auVar42[6] = -(pcVar1[6] == (char)((uint)iVar9 >> 0x10));
    auVar42[7] = -(pcVar1[7] == (char)((uint)iVar9 >> 0x18));
    auVar42[8] = -(pcVar1[8] == (char)iVar10);
    auVar42[9] = -(pcVar1[9] == (char)((uint)iVar10 >> 8));
    auVar42[10] = -(pcVar1[10] == (char)((uint)iVar10 >> 0x10));
    auVar42[0xb] = -(pcVar1[0xb] == (char)((uint)iVar10 >> 0x18));
    auVar42[0xc] = -(pcVar1[0xc] == (char)iVar11);
    auVar42[0xd] = -(pcVar1[0xd] == (char)((uint)iVar11 >> 8));
    auVar42[0xe] = -(pcVar1[0xe] == (char)((uint)iVar11 >> 0x10));
    auVar42[0xf] = -(pcVar1[0xf] == (char)((uint)iVar11 >> 0x18));
    if ((((((((((((((((SUB161(auVar42 >> 7,0) & 1) != 0 || (SUB161(auVar42 >> 0xf,0) & 1) != 0) ||
                    (SUB161(auVar42 >> 0x17,0) & 1) != 0) || (SUB161(auVar42 >> 0x1f,0) & 1) != 0)
                  || (SUB161(auVar42 >> 0x27,0) & 1) != 0) || (SUB161(auVar42 >> 0x2f,0) & 1) != 0)
                || (SUB161(auVar42 >> 0x37,0) & 1) != 0) || (SUB161(auVar42 >> 0x3f,0) & 1) != 0) ||
              (SUB161(auVar42 >> 0x47,0) & 1) != 0) || (SUB161(auVar42 >> 0x4f,0) & 1) != 0) ||
            (SUB161(auVar42 >> 0x57,0) & 1) != 0) || (SUB161(auVar42 >> 0x5f,0) & 1) != 0) ||
          (SUB161(auVar42 >> 0x67,0) & 1) != 0) || (SUB161(auVar42 >> 0x6f,0) & 1) != 0) ||
        (SUB161(auVar42 >> 0x77,0) & 1) != 0) || auVar42[0xf] < '\0') break;
    lVar14 = uVar15 + lVar29;
    lVar29 = lVar29 + 0x10;
    uVar15 = lVar14 + 0x10U & uVar25;
  }
  if (*(longlong *)local_90[1] == 0) {
    local_b8 = (ulonglong *)extraout_RAX;
    hashbrown::raw::RawTable::
    reserve_rehash<tuple_<country_core::resources::walls::WallId,alloc::vec::Vec<country_core::resources::walls::wall_stone_columns::StoneColumn,alloc::alloc::Global>_>,alloc::alloc::Global,hashbrown::map::make_hasher::closure_env_0<country_core::resources::walls::WallId,alloc::vec::Vec<country_core::resources::walls::wall_stone_columns::StoneColumn,alloc::alloc::Global>,std::hash::random::RandomState>_>
              ();
    pauVar18 = *(undefined1 (**) [16])*pauVar16;
    uVar25 = *(ulonglong *)(*pauVar16 + 8);
    uVar24 = (ulonglong)local_b8 & uVar25;
    auVar38 = *(undefined1 (*) [16])((longlong)*pauVar18 + uVar24);
    uVar26 = (ushort)(SUB161(auVar38 >> 7,0) & 1) | (ushort)(SUB161(auVar38 >> 0xf,0) & 1) << 1 |
             (ushort)(SUB161(auVar38 >> 0x17,0) & 1) << 2 |
             (ushort)(SUB161(auVar38 >> 0x1f,0) & 1) << 3 |
             (ushort)(SUB161(auVar38 >> 0x27,0) & 1) << 4 |
             (ushort)(SUB161(auVar38 >> 0x2f,0) & 1) << 5 |
             (ushort)(SUB161(auVar38 >> 0x37,0) & 1) << 6 |
             (ushort)(SUB161(auVar38 >> 0x3f,0) & 1) << 7 |
             (ushort)(SUB161(auVar38 >> 0x47,0) & 1) << 8 |
             (ushort)(SUB161(auVar38 >> 0x4f,0) & 1) << 9 |
             (ushort)(SUB161(auVar38 >> 0x57,0) & 1) << 10 |
             (ushort)(SUB161(auVar38 >> 0x5f,0) & 1) << 0xb |
             (ushort)(SUB161(auVar38 >> 0x67,0) & 1) << 0xc |
             (ushort)(SUB161(auVar38 >> 0x6f,0) & 1) << 0xd |
             (ushort)(SUB161(auVar38 >> 0x77,0) & 1) << 0xe |
             (ushort)(byte)(auVar38[0xf] >> 7) << 0xf;
    if (uVar26 != 0) goto LAB_140755c64;
LAB_140755d2c:
    lVar29 = 0x10;
    do {
      uVar24 = uVar24 + lVar29 & uVar25;
      auVar38 = *(undefined1 (*) [16])((longlong)*pauVar18 + uVar24);
      lVar29 = lVar29 + 0x10;
      uVar12 = (uint)(ushort)((ushort)(SUB161(auVar38 >> 7,0) & 1) |
                              (ushort)(SUB161(auVar38 >> 0xf,0) & 1) << 1 |
                              (ushort)(SUB161(auVar38 >> 0x17,0) & 1) << 2 |
                              (ushort)(SUB161(auVar38 >> 0x1f,0) & 1) << 3 |
                              (ushort)(SUB161(auVar38 >> 0x27,0) & 1) << 4 |
                              (ushort)(SUB161(auVar38 >> 0x2f,0) & 1) << 5 |
                              (ushort)(SUB161(auVar38 >> 0x37,0) & 1) << 6 |
                              (ushort)(SUB161(auVar38 >> 0x3f,0) & 1) << 7 |
                              (ushort)(SUB161(auVar38 >> 0x47,0) & 1) << 8 |
                              (ushort)(SUB161(auVar38 >> 0x4f,0) & 1) << 9 |
                              (ushort)(SUB161(auVar38 >> 0x57,0) & 1) << 10 |
                              (ushort)(SUB161(auVar38 >> 0x5f,0) & 1) << 0xb |
                              (ushort)(SUB161(auVar38 >> 0x67,0) & 1) << 0xc |
                              (ushort)(SUB161(auVar38 >> 0x6f,0) & 1) << 0xd |
                              (ushort)(SUB161(auVar38 >> 0x77,0) & 1) << 0xe |
                             (ushort)(byte)(auVar38[0xf] >> 7) << 0xf);
    } while (uVar12 == 0);
  }
  else {
    auVar38 = *(undefined1 (*) [16])((longlong)*pauVar18 + uVar24);
    uVar26 = (ushort)(SUB161(auVar38 >> 7,0) & 1) | (ushort)(SUB161(auVar38 >> 0xf,0) & 1) << 1 |
             (ushort)(SUB161(auVar38 >> 0x17,0) & 1) << 2 |
             (ushort)(SUB161(auVar38 >> 0x1f,0) & 1) << 3 |
             (ushort)(SUB161(auVar38 >> 0x27,0) & 1) << 4 |
             (ushort)(SUB161(auVar38 >> 0x2f,0) & 1) << 5 |
             (ushort)(SUB161(auVar38 >> 0x37,0) & 1) << 6 |
             (ushort)(SUB161(auVar38 >> 0x3f,0) & 1) << 7 |
             (ushort)(SUB161(auVar38 >> 0x47,0) & 1) << 8 |
             (ushort)(SUB161(auVar38 >> 0x4f,0) & 1) << 9 |
             (ushort)(SUB161(auVar38 >> 0x57,0) & 1) << 10 |
             (ushort)(SUB161(auVar38 >> 0x5f,0) & 1) << 0xb |
             (ushort)(SUB161(auVar38 >> 0x67,0) & 1) << 0xc |
             (ushort)(SUB161(auVar38 >> 0x6f,0) & 1) << 0xd |
             (ushort)(SUB161(auVar38 >> 0x77,0) & 1) << 0xe |
             (ushort)(byte)(auVar38[0xf] >> 7) << 0xf;
    if (uVar26 == 0) goto LAB_140755d2c;
LAB_140755c64:
    uVar12 = (uint)uVar26;
  }
  uVar13 = 0;
  for (; (uVar12 & 1) == 0; uVar12 = uVar12 >> 1 | 0x80000000) {
    uVar13 = uVar13 + 1;
  }
  uVar15 = uVar13 + uVar24 & uVar25;
  bVar36 = *(byte *)((longlong)*pauVar18 + uVar15);
  if (-1 < (char)bVar36) {
    auVar38 = *pauVar18;
    uVar12 = 0;
    for (uVar13 = (uint)(ushort)((ushort)(SUB161(auVar38 >> 7,0) & 1) |
                                 (ushort)(SUB161(auVar38 >> 0xf,0) & 1) << 1 |
                                 (ushort)(SUB161(auVar38 >> 0x17,0) & 1) << 2 |
                                 (ushort)(SUB161(auVar38 >> 0x1f,0) & 1) << 3 |
                                 (ushort)(SUB161(auVar38 >> 0x27,0) & 1) << 4 |
                                 (ushort)(SUB161(auVar38 >> 0x2f,0) & 1) << 5 |
                                 (ushort)(SUB161(auVar38 >> 0x37,0) & 1) << 6 |
                                 (ushort)(SUB161(auVar38 >> 0x3f,0) & 1) << 7 |
                                 (ushort)(SUB161(auVar38 >> 0x47,0) & 1) << 8 |
                                 (ushort)(SUB161(auVar38 >> 0x4f,0) & 1) << 9 |
                                 (ushort)(SUB161(auVar38 >> 0x57,0) & 1) << 10 |
                                 (ushort)(SUB161(auVar38 >> 0x5f,0) & 1) << 0xb |
                                 (ushort)(SUB161(auVar38 >> 0x67,0) & 1) << 0xc |
                                 (ushort)(SUB161(auVar38 >> 0x6f,0) & 1) << 0xd |
                                 (ushort)(SUB161(auVar38 >> 0x77,0) & 1) << 0xe |
                                (ushort)(byte)(auVar38[0xf] >> 7) << 0xf); (uVar13 & 1) == 0;
        uVar13 = uVar13 >> 1 | 0x80000000) {
      uVar12 = uVar12 + 1;
    }
    uVar15 = (ulonglong)uVar12;
    bVar36 = *(byte *)((longlong)*pauVar18 + uVar15);
  }
  bVar35 = bVar35 >> 1;
  *(byte *)((longlong)*pauVar18 + uVar15) = bVar35;
  *(byte *)((longlong)pauVar18[1] + (uVar15 - 0x10 & uVar25)) = bVar35;
  *(ulonglong *)local_90[1] = *(longlong *)local_90[1] - (ulonglong)(bVar36 & 1);
  pauVar16 = (undefined1 (*) [16])(uVar15 * -0x20);
  *(undefined8 **)(pauVar18 + -2)[uVar15 * -2] = local_88;
  *(undefined8 *)((longlong)pauVar18[uVar15 * -2 + -2] + 8) = 0;
  *(undefined8 *)pauVar18[uVar15 * -2 + -1] = 8;
  *(undefined8 *)((longlong)pauVar18[uVar15 * -2 + -1] + 8) = 0;
  *(longlong *)(local_90[1] + 8) = *(longlong *)(local_90[1] + 8) + 1;
  if ((local_78 & 1) == 0) goto LAB_1407558bd;
  goto LAB_140755900;
  while( true ) {
    pauVar18 = (undefined1 (*) [16])&local_e0;
    local_e0 = puVar4;
    local_d8 = lVar31;
    local_d0 = uVar6;
    local_c8 = uVar5;
    local_c0 = pauVar16;
    local_88 = puVar33 + 1;
    bevy_ecs::system::commands::EntityCommands::despawn();
    lVar29 = lVar29 + -8;
    pauVar16 = extraout_RAX_00;
    puVar33 = local_88;
    if (lVar29 == 0) break;
LAB_140755be0:
    pauVar16 = (undefined1 (*) [16])*puVar33;
    pauVar18 = (undefined1 (*) [16])0x0;
    if ((ulonglong)pauVar16 >> 0x20 == 0) break;
  }
LAB_1407558b0:
  if ((local_78 & 1) != 0) goto LAB_140755900;
LAB_1407558bd:
  pauVar16 = local_98;
  if (local_70 == (undefined1 (*) [16])0x0) goto LAB_140755a30;
LAB_1407558d4:
  pauVar16 = local_98;
  if (local_70 == pauVar20) goto LAB_140755a30;
  local_78 = 0;
  pauVar16 = local_70;
  puVar17 = local_a8;
  local_70 = local_70 + 2;
  goto LAB_140755a6b;
}

