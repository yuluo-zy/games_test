
void __cdecl country_core::resources::history::wall_compound_edit::CompoundEditBuilder::build(void)

{
  longlong *in_RCX;
  
  *in_RCX = 0;
  in_RCX[1] = 8;
  in_RCX[2] = 0;
  alloc::boxed::iter::impl$13::
  from_iter<country_core::resources::history::wall_compound_edit::ConcurrentEdits,core::iter::adapters::map::Map<alloc::vec::into_iter::IntoIter<alloc::vec::Vec<alloc::sync::Arc<enum2_<country_core::resources::history::wall_compound_edit::WallHistoryEdit>,alloc::alloc::Global>,alloc::alloc::Global>,alloc::alloc::Global>,country_core::resources::history::wall_compound_edit::impl_0::new::closure_env_0>_>
            ();
  if (*in_RCX != 0) {
    std::alloc::__default_lib_allocator::__rust_dealloc();
  }
  return;
}

