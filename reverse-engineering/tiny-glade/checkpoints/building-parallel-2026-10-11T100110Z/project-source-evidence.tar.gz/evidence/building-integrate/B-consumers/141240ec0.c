
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __cdecl system_wall_constructor::utils::split_horizontally(void)

{
  undefined8 *puVar1;
  float *pfVar2;
  float fVar3;
  float fVar4;
  longlong lVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  float *in_R8;
  int in_R9D;
  float in_XMM0_Da;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  ulonglong *in_stack_00000028;
  undefined8 local_d8;
  undefined8 uStack_d0;
  
  fVar9 = in_XMM0_Da * ___real_3ecccccc + __real_3e99999a;
  ::utils::geometry::aabb::Aabb2::height();
  ::utils::geometry::aabb::Aabb2::height();
  fVar13 = __real_3f800000 - fVar9;
  ::utils::geometry::aabb::Aabb2::width();
  ::utils::geometry::aabb::Aabb2::center();
  fVar3 = *in_R8;
  fVar4 = in_R8[1];
  fVar11 = (float)*(undefined8 *)(in_R8 + 2);
  fVar12 = (float)((ulonglong)*(undefined8 *)(in_R8 + 2) >> 0x20);
  fVar10 = fVar9 * fVar11 + fVar13 * fVar3;
  fVar9 = fVar9 * fVar12 + fVar13 * fVar4;
  ::utils::geometry::aabb::Aabb2::from_center_dims();
  uVar7 = *in_stack_00000028;
  uVar6 = in_stack_00000028[3];
  if (uVar6 == uVar7) {
    alloc::collections::vec_deque::VecDeque::
    grow<system_wall_constructor::utils::MyBrick,alloc::alloc::Global>();
    uVar7 = *in_stack_00000028;
    uVar6 = in_stack_00000028[3];
  }
  uVar8 = 0;
  if (uVar7 <= uVar6 + in_stack_00000028[2]) {
    uVar8 = uVar7;
  }
  lVar5 = (uVar6 + in_stack_00000028[2]) - uVar8;
  uVar7 = in_stack_00000028[1];
  puVar1 = (undefined8 *)(uVar7 + lVar5 * 0x28);
  *puVar1 = local_d8;
  puVar1[1] = uStack_d0;
  pfVar2 = (float *)(uVar7 + 0x10 + lVar5 * 0x28);
  *pfVar2 = fVar3;
  pfVar2[1] = fVar4;
  pfVar2[2] = fVar10;
  pfVar2[3] = fVar9;
  *(int *)(uVar7 + 0x20 + lVar5 * 0x28) = in_R9D;
  *(undefined2 *)(uVar7 + 0x24 + lVar5 * 0x28) = 0;
  in_stack_00000028[3] = in_stack_00000028[3] + 1;
  ::utils::geometry::aabb::Aabb2::from_center_dims();
  uVar7 = *in_stack_00000028;
  uVar6 = in_stack_00000028[3];
  if (uVar6 == uVar7) {
    alloc::collections::vec_deque::VecDeque::
    grow<system_wall_constructor::utils::MyBrick,alloc::alloc::Global>();
    uVar7 = *in_stack_00000028;
    uVar6 = in_stack_00000028[3];
  }
  uVar8 = 0;
  if (uVar7 <= uVar6 + in_stack_00000028[2]) {
    uVar8 = uVar7;
  }
  lVar5 = (uVar6 + in_stack_00000028[2]) - uVar8;
  uVar7 = in_stack_00000028[1];
  puVar1 = (undefined8 *)(uVar7 + lVar5 * 0x28);
  *puVar1 = local_d8;
  puVar1[1] = uStack_d0;
  pfVar2 = (float *)(uVar7 + 0x10 + lVar5 * 0x28);
  *pfVar2 = fVar10;
  pfVar2[1] = fVar9;
  pfVar2[2] = fVar11;
  pfVar2[3] = fVar12;
  *(int *)(uVar7 + 0x20 + lVar5 * 0x28) = in_R9D + 1;
  *(undefined2 *)(uVar7 + 0x24 + lVar5 * 0x28) = 0;
  in_stack_00000028[3] = in_stack_00000028[3] + 1;
  return;
}

