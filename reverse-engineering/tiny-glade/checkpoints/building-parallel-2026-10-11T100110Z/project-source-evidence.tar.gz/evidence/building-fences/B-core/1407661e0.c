
void __cdecl system_wall_constructor::construct_floors::construct_floors(void)

{
  char *pcVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  ulonglong *puVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  char extraout_AL;
  char extraout_AL_00;
  longlong lVar15;
  longlong lVar16;
  ulonglong extraout_RAX;
  ulonglong *extraout_RAX_00;
  longlong *in_RCX;
  ulonglong uVar17;
  longlong lVar18;
  undefined8 *in_RDX;
  longlong lVar19;
  ushort uVar20;
  longlong lVar21;
  longlong lVar22;
  undefined8 *in_R8;
  ulonglong uVar23;
  ulonglong uVar24;
  ulonglong uVar25;
  longlong lVar26;
  uint uVar27;
  longlong *plVar28;
  longlong *plVar29;
  byte bVar30;
  char cVar31;
  char cVar33;
  char cVar34;
  char cVar35;
  undefined1 auVar32 [16];
  undefined1 auVar36 [16];
  undefined1 auVar37 [16];
  undefined1 unaff_XMM6_Ba;
  undefined1 unaff_XMM6_Bb;
  undefined1 unaff_XMM6_Bc;
  undefined1 unaff_XMM6_Bd;
  undefined1 unaff_XMM6_Be;
  undefined1 unaff_XMM6_Bf;
  undefined1 unaff_XMM6_Bg;
  undefined1 unaff_XMM6_Bh;
  undefined1 unaff_XMM6_Bi;
  undefined1 unaff_XMM6_Bj;
  undefined1 unaff_XMM6_Bk;
  undefined1 unaff_XMM6_Bl;
  undefined1 unaff_XMM6_Bm;
  undefined1 unaff_XMM6_Bn;
  undefined1 unaff_XMM6_Bo;
  undefined1 unaff_XMM6_Bp;
  longlong in_stack_00000028;
  longlong local_1d0;
  undefined4 uStack_190;
  undefined8 uStack_170;
  undefined8 uStack_168;
  undefined4 uStack_160;
  undefined8 uStack_150;
  undefined7 uStack_137;
  undefined8 uStack_130;
  undefined4 uStack_104;
  undefined8 uStack_100;
  undefined8 local_f8;
  longlong *plStack_f0;
  longlong *local_e8;
  undefined4 local_dc;
  undefined4 uStack_d8;
  undefined4 local_d4;
  undefined8 local_c8;
  undefined8 uStack_c0;
  
  puVar4 = (ulonglong *)*in_R8;
  lVar19 = in_R8[1];
  uVar25 = *puVar4;
  uVar23 = 0;
  uVar17 = uVar25 - *(ulonglong *)(lVar19 + 0x18);
  if (uVar25 < *(ulonglong *)(lVar19 + 0x18)) {
    uVar17 = uVar23;
  }
  uVar24 = uVar25 - *(ulonglong *)(lVar19 + 0x38);
  if (uVar25 < *(ulonglong *)(lVar19 + 0x38)) {
    uVar24 = uVar23;
  }
  lVar15 = uVar17 * 0x10 + *(longlong *)(lVar19 + 8);
  uVar25 = *(ulonglong *)(lVar19 + 0x10) - uVar17;
  if (*(ulonglong *)(lVar19 + 0x10) < uVar17) {
    lVar15 = 8;
    uVar25 = uVar23;
  }
  lVar18 = uVar24 * 0x10 + *(longlong *)(lVar19 + 0x28);
  uVar17 = *(ulonglong *)(lVar19 + 0x30) - uVar24;
  if (*(ulonglong *)(lVar19 + 0x30) < uVar24) {
    lVar18 = 8;
    uVar17 = uVar23;
  }
  *puVar4 = (*(longlong *)(lVar19 + 0x40) - uVar17) - uVar25;
  lVar19 = uVar25 * 0x10 + lVar15;
  lVar21 = uVar17 * 0x10 + lVar18;
  do {
    if ((lVar15 == 0) || (lVar15 == lVar19)) {
      if ((lVar18 == 0) || (lVar18 == lVar21)) {
        puVar4 = (ulonglong *)*in_RDX;
        lVar19 = in_RDX[1];
        uVar25 = *puVar4;
        uVar23 = 0;
        uVar17 = uVar25 - *(ulonglong *)(lVar19 + 0x18);
        if (uVar25 < *(ulonglong *)(lVar19 + 0x18)) {
          uVar17 = uVar23;
        }
        uVar24 = uVar25 - *(ulonglong *)(lVar19 + 0x38);
        if (uVar25 < *(ulonglong *)(lVar19 + 0x38)) {
          uVar24 = uVar23;
        }
        lVar15 = uVar17 * 0x10 + *(longlong *)(lVar19 + 8);
        uVar25 = *(ulonglong *)(lVar19 + 0x10) - uVar17;
        if (*(ulonglong *)(lVar19 + 0x10) < uVar17) {
          lVar15 = 8;
          uVar25 = uVar23;
        }
        local_1d0 = uVar24 * 0x10 + *(longlong *)(lVar19 + 0x28);
        uVar17 = *(ulonglong *)(lVar19 + 0x30) - uVar24;
        if (*(ulonglong *)(lVar19 + 0x30) < uVar24) {
          local_1d0 = 8;
          uVar17 = uVar23;
        }
        *puVar4 = (*(longlong *)(lVar19 + 0x40) - uVar17) - uVar25;
        fVar14 = __real_40400000;
        fVar13 = __real_3f800000;
        lVar19 = uVar25 * 0x10 + lVar15;
        lVar18 = uVar17 * 0x10 + local_1d0;
        plVar28 = (longlong *)*in_RCX;
        iVar7 = -(uint)(CONCAT13(unaff_XMM6_Bd,
                                 CONCAT12(unaff_XMM6_Bc,CONCAT11(unaff_XMM6_Bb,unaff_XMM6_Ba))) ==
                       CONCAT13(unaff_XMM6_Bd,
                                CONCAT12(unaff_XMM6_Bc,CONCAT11(unaff_XMM6_Bb,unaff_XMM6_Ba))));
        iVar8 = -(uint)(CONCAT13(unaff_XMM6_Bh,
                                 CONCAT12(unaff_XMM6_Bg,CONCAT11(unaff_XMM6_Bf,unaff_XMM6_Be))) ==
                       CONCAT13(unaff_XMM6_Bh,
                                CONCAT12(unaff_XMM6_Bg,CONCAT11(unaff_XMM6_Bf,unaff_XMM6_Be))));
        iVar9 = -(uint)(CONCAT13(unaff_XMM6_Bl,
                                 CONCAT12(unaff_XMM6_Bk,CONCAT11(unaff_XMM6_Bj,unaff_XMM6_Bi))) ==
                       CONCAT13(unaff_XMM6_Bl,
                                CONCAT12(unaff_XMM6_Bk,CONCAT11(unaff_XMM6_Bj,unaff_XMM6_Bi))));
        iVar10 = -(uint)(CONCAT13(unaff_XMM6_Bp,
                                  CONCAT12(unaff_XMM6_Bo,CONCAT11(unaff_XMM6_Bn,unaff_XMM6_Bm))) ==
                        CONCAT13(unaff_XMM6_Bp,
                                 CONCAT12(unaff_XMM6_Bo,CONCAT11(unaff_XMM6_Bn,unaff_XMM6_Bm))));
LAB_14076649a:
        if ((lVar15 == 0) || (lVar15 == lVar19)) {
          if ((local_1d0 == 0) || (local_1d0 == lVar18)) {
            return;
          }
          lVar15 = 0;
          lVar21 = local_1d0;
          local_1d0 = local_1d0 + 0x10;
        }
        else {
          lVar21 = lVar15;
          lVar15 = lVar15 + 0x10;
        }
        *puVar4 = *puVar4 + 1;
        lVar21 = *(longlong *)(lVar21 + 8);
        core::hash::BuildHasher::
        hash_one<std::hash::random::RandomState,ref_<country_core::systems::ui::GlobalId>_>();
        hashbrown::raw::RawTable::
        remove_entry<tuple_<country_core::resources::walls::WallId,bevy_ecs::entity::Entity>,alloc::alloc::Global,hashbrown::map::equivalent_key::closure_env_0<country_core::resources::walls::WallId,country_core::resources::walls::WallId,bevy_ecs::entity::Entity>_>
                  ();
        plVar29 = (longlong *)0x0;
        if (uStack_170._4_4_ != 0) {
          plVar29 = uStack_170;
        }
        if (((ulonglong)plVar29 >> 0x20 != 0) &&
           (bevy_ecs::entity::Entities::contains(), extraout_AL_00 != '\0')) {
          uStack_170 = *(longlong **)(in_stack_00000028 + 8);
          uStack_168 = *(undefined8 *)(in_stack_00000028 + 0x10);
          uStack_160 = (undefined4)*(undefined8 *)(in_stack_00000028 + 0x18);
          bevy_ecs::system::commands::EntityCommands::despawn();
        }
        if (plVar28[3] != 0) {
          core::hash::BuildHasher::
          hash_one<std::hash::random::RandomState,ref_<country_core::systems::ui::GlobalId>_>();
          lVar16 = *plVar28;
          bVar30 = (byte)(extraout_RAX >> 0x39);
          auVar32 = ZEXT216(CONCAT11(bVar30,bVar30));
          auVar32 = pshuflw(auVar32,auVar32,0);
          lVar26 = 0;
          uVar25 = extraout_RAX;
          while( true ) {
            uVar25 = plVar28[1] & uVar25;
            pcVar1 = (char *)(lVar16 + uVar25);
            cVar31 = auVar32[0];
            auVar37[0] = -(*pcVar1 == cVar31);
            cVar33 = auVar32[1];
            auVar37[1] = -(pcVar1[1] == cVar33);
            cVar34 = auVar32[2];
            auVar37[2] = -(pcVar1[2] == cVar34);
            cVar35 = auVar32[3];
            auVar37[3] = -(pcVar1[3] == cVar35);
            auVar37[4] = -(pcVar1[4] == cVar31);
            auVar37[5] = -(pcVar1[5] == cVar33);
            auVar37[6] = -(pcVar1[6] == cVar34);
            auVar37[7] = -(pcVar1[7] == cVar35);
            auVar37[8] = -(pcVar1[8] == cVar31);
            auVar37[9] = -(pcVar1[9] == cVar33);
            auVar37[10] = -(pcVar1[10] == cVar34);
            auVar37[0xb] = -(pcVar1[0xb] == cVar35);
            auVar37[0xc] = -(pcVar1[0xc] == cVar31);
            auVar37[0xd] = -(pcVar1[0xd] == cVar33);
            auVar37[0xe] = -(pcVar1[0xe] == cVar34);
            auVar37[0xf] = -(pcVar1[0xf] == cVar35);
            uVar20 = (ushort)(SUB161(auVar37 >> 7,0) & 1) |
                     (ushort)(SUB161(auVar37 >> 0xf,0) & 1) << 1 |
                     (ushort)(SUB161(auVar37 >> 0x17,0) & 1) << 2 |
                     (ushort)(SUB161(auVar37 >> 0x1f,0) & 1) << 3 |
                     (ushort)(SUB161(auVar37 >> 0x27,0) & 1) << 4 |
                     (ushort)(SUB161(auVar37 >> 0x2f,0) & 1) << 5 |
                     (ushort)(SUB161(auVar37 >> 0x37,0) & 1) << 6 |
                     (ushort)(SUB161(auVar37 >> 0x3f,0) & 1) << 7 |
                     (ushort)(SUB161(auVar37 >> 0x47,0) & 1) << 8 |
                     (ushort)(SUB161(auVar37 >> 0x4f,0) & 1) << 9 |
                     (ushort)(SUB161(auVar37 >> 0x57,0) & 1) << 10 |
                     (ushort)(SUB161(auVar37 >> 0x5f,0) & 1) << 0xb |
                     (ushort)(SUB161(auVar37 >> 0x67,0) & 1) << 0xc |
                     (ushort)(SUB161(auVar37 >> 0x6f,0) & 1) << 0xd |
                     (ushort)(SUB161(auVar37 >> 0x77,0) & 1) << 0xe |
                     (ushort)(auVar37[0xf] >> 7) << 0xf;
            uVar27 = (uint)uVar20;
            while (uVar20 != 0) {
              uVar5 = 0;
              for (uVar6 = uVar27; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
                uVar5 = uVar5 + 1;
              }
              lVar22 = (uVar5 + uVar25 & plVar28[1]) * -0x2a8;
              if (lVar21 == *(longlong *)(lVar16 + -0x2a8 + lVar22)) {
                if ((0.0 < *(float *)(lVar16 + -0x20 + lVar22)) &&
                   (*(uint *)(lVar16 + lVar22 + -0x48) < 2)) {
                  country_core::resources::walls::public_wall_state::PublicWallState::get_wall_shape
                            ();
                  uVar25 = *extraout_RAX_00;
                  fVar12 = *(float *)((longlong)extraout_RAX_00 + 0xc);
                  uVar17 = extraout_RAX_00[2];
                  uVar23 = extraout_RAX_00[3];
                  uStack_190 = (undefined4)extraout_RAX_00[1];
                  if ((uVar25 & 1) == 0) {
                    fVar11 = fVar12;
                    if (fVar12 <= fVar13) {
                      fVar11 = fVar13;
                    }
                    log2f(fVar11 * fVar14);
                  }
                  country_core::resources::walls::decorator::DecoratorRank::new();
                  country_core::components::drawable::impl$1::from();
                  country_core::systems::wall::valid_enclosure::ShapeParameters::center();
                  ::utils::swizzlers::impl$1::xvy();
                  ::utils::components::transform::impl$1::default();
                  bevy_app::plugin::Plugin::
                  finish<country_core::systems::main_camera::MainCameraPlugin>();
                  uStack_170 = plStack_f0;
                  bevy_ecs::system::commands::Commands::spawn_empty();
                  plVar29 = plStack_f0;
                  if (plStack_f0 == (longlong *)0x0) {
                    plVar29 = local_e8;
                  }
                  lVar16 = plVar29[2];
                  if ((ulonglong)(*plVar29 - lVar16) < 0xb8) {
                    alloc::raw_vec::impl$4::reserve::do_reserve_and_handle<alloc::alloc::Global>();
                  }
                  lVar26 = plVar29[1];
                  *(code **)(lVar26 + lVar16) =
                       core::ops::function::FnOnce::
                       call_once<bevy_ecs::world::command_queue::impl_4::push::closure_env_0<bevy_ecs::error::command_handling::impl_0::handle_error_with::closure_env_0<bevy_ecs::error::command_handling::impl_3::with_entity::closure_env_0<bevy_ecs::system::commands::entity_command::insert::closure_env_0<tuple_<country_core::components::drawable::NaniBundle<country_core::render::nani::instance_data::StoneFloorInstanceData>,country_core::resources::walls::Floor>_>_>,tuple_<>,enum2_<bevy_ecs::world::error::EntityMutableFetchError>_>_>,tuple_<bevy_ptr::OwningPtr<bevy_ptr::Unaligned>,enum2_<core::option::Option<core::ptr::non_null::NonNull<bevy_ecs::world::World>_>_>,ref_mut_<usize>_>_>
                  ;
                  puVar2 = (undefined8 *)(lVar26 + 8 + lVar16);
                  *puVar2 = local_f8;
                  puVar2[1] = plStack_f0;
                  puVar2 = (undefined8 *)(lVar26 + 0x18 + lVar16);
                  *puVar2 = uStack_168;
                  puVar2[1] = CONCAT44(local_dc,uStack_160);
                  puVar2 = (undefined8 *)(lVar26 + 0x28 + lVar16);
                  *puVar2 = CONCAT44(local_d4,uStack_d8);
                  puVar2[1] = uStack_150;
                  puVar2 = (undefined8 *)(lVar26 + 0x38 + lVar16);
                  *puVar2 = local_c8;
                  puVar2[1] = uStack_c0;
                  puVar2 = (undefined8 *)(lVar26 + 0x48 + lVar16);
                  *puVar2 = CONCAT71(uStack_137,9);
                  puVar2[1] = uStack_130;
                  plVar3 = (longlong *)(lVar26 + 0x58 + lVar16);
                  *plVar3 = lVar21;
                  plVar3[1] = uVar25;
                  puVar2 = (undefined8 *)(lVar26 + 0x68 + lVar16);
                  *puVar2 = CONCAT44(fVar12,uStack_190);
                  puVar2[1] = uVar17;
                  puVar2 = (undefined8 *)(lVar26 + 0x78 + lVar16);
                  *puVar2 = CONCAT44(uStack_104,(int)uVar23);
                  puVar2[1] = uStack_100;
                  *(undefined1 *)(lVar26 + 0x88 + lVar16) = 0;
                  *(ulonglong *)(lVar26 + 0x98 + lVar16) = CONCAT44(local_d4,uStack_d8);
                  *(code **)(lVar26 + 0xa8 + lVar16) = bevy_ecs::error::handler::panic;
                  plVar29[2] = lVar16 + 0xb8;
                  hashbrown::map::HashMap::
                  insert<u64,ref_<system_clutter::autoclutter::AutoClutterObject>,std::hash::random::RandomState,alloc::alloc::Global>
                            ();
                }
                goto LAB_14076649a;
              }
              uVar20 = (ushort)(uVar27 - 1) & (ushort)uVar27;
              uVar27 = CONCAT22((short)(uVar27 - 1 >> 0x10),uVar20);
            }
            auVar36[0] = -(*pcVar1 == (char)iVar7);
            auVar36[1] = -(pcVar1[1] == (char)((uint)iVar7 >> 8));
            auVar36[2] = -(pcVar1[2] == (char)((uint)iVar7 >> 0x10));
            auVar36[3] = -(pcVar1[3] == (char)((uint)iVar7 >> 0x18));
            auVar36[4] = -(pcVar1[4] == (char)iVar8);
            auVar36[5] = -(pcVar1[5] == (char)((uint)iVar8 >> 8));
            auVar36[6] = -(pcVar1[6] == (char)((uint)iVar8 >> 0x10));
            auVar36[7] = -(pcVar1[7] == (char)((uint)iVar8 >> 0x18));
            auVar36[8] = -(pcVar1[8] == (char)iVar9);
            auVar36[9] = -(pcVar1[9] == (char)((uint)iVar9 >> 8));
            auVar36[10] = -(pcVar1[10] == (char)((uint)iVar9 >> 0x10));
            auVar36[0xb] = -(pcVar1[0xb] == (char)((uint)iVar9 >> 0x18));
            auVar36[0xc] = -(pcVar1[0xc] == (char)iVar10);
            auVar36[0xd] = -(pcVar1[0xd] == (char)((uint)iVar10 >> 8));
            auVar36[0xe] = -(pcVar1[0xe] == (char)((uint)iVar10 >> 0x10));
            auVar36[0xf] = -(pcVar1[0xf] == (char)((uint)iVar10 >> 0x18));
            if ((((((((((((((((SUB161(auVar36 >> 7,0) & 1) != 0 ||
                             (SUB161(auVar36 >> 0xf,0) & 1) != 0) ||
                            (SUB161(auVar36 >> 0x17,0) & 1) != 0) ||
                           (SUB161(auVar36 >> 0x1f,0) & 1) != 0) ||
                          (SUB161(auVar36 >> 0x27,0) & 1) != 0) ||
                         (SUB161(auVar36 >> 0x2f,0) & 1) != 0) ||
                        (SUB161(auVar36 >> 0x37,0) & 1) != 0) ||
                       (SUB161(auVar36 >> 0x3f,0) & 1) != 0) || (SUB161(auVar36 >> 0x47,0) & 1) != 0
                      ) || (SUB161(auVar36 >> 0x4f,0) & 1) != 0) ||
                    (SUB161(auVar36 >> 0x57,0) & 1) != 0) || (SUB161(auVar36 >> 0x5f,0) & 1) != 0)
                  || (SUB161(auVar36 >> 0x67,0) & 1) != 0) || (SUB161(auVar36 >> 0x6f,0) & 1) != 0)
                || (SUB161(auVar36 >> 0x77,0) & 1) != 0) || auVar36[0xf] < '\0') break;
            uVar25 = uVar25 + lVar26 + 0x10;
            lVar26 = lVar26 + 0x10;
          }
        }
                    /* WARNING: Subroutine does not return */
        core::option::unwrap_failed();
      }
      lVar15 = 0;
      lVar16 = lVar18;
      lVar18 = lVar18 + 0x10;
    }
    else {
      lVar16 = lVar15;
      lVar15 = lVar15 + 0x10;
    }
    *puVar4 = *puVar4 + 1;
    local_f8 = *(undefined8 *)(lVar16 + 8);
    core::hash::BuildHasher::
    hash_one<std::hash::random::RandomState,ref_<country_core::systems::ui::GlobalId>_>();
    hashbrown::raw::RawTable::
    remove_entry<tuple_<country_core::resources::walls::WallId,bevy_ecs::entity::Entity>,alloc::alloc::Global,hashbrown::map::equivalent_key::closure_env_0<country_core::resources::walls::WallId,country_core::resources::walls::WallId,bevy_ecs::entity::Entity>_>
              ();
    plVar28 = (longlong *)0x0;
    if (uStack_170._4_4_ != 0) {
      plVar28 = uStack_170;
    }
    if (((ulonglong)plVar28 >> 0x20 != 0) &&
       (bevy_ecs::entity::Entities::contains(), extraout_AL != '\0')) {
      uStack_170 = *(longlong **)(in_stack_00000028 + 8);
      uStack_168 = *(undefined8 *)(in_stack_00000028 + 0x10);
      uStack_160 = (undefined4)*(undefined8 *)(in_stack_00000028 + 0x18);
      bevy_ecs::system::commands::EntityCommands::despawn();
    }
  } while( true );
}

